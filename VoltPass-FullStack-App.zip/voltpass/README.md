# VoltPass — EU Digital Battery Passport & Second-Life Marketplace

A full-stack web application implementing **EU Regulation 2023/1542 (Article 77 & Annex XIII)** for Digital Battery Passports, Role-Based Access Control (RBAC) data masking, Article 8 circularity tracking (2031 EU targets), biometric facial scan authentication, and Second-Life BESS valuation & repurposing workflows.

---

## Tech Stack

- **Backend (`/backend`)**: Python 3.12, FastAPI, SQLAlchemy ORM, SQLite (`voltpass.db`), Pydantic v2, PyJWT (`HS256`), PBKDF2-HMAC-SHA256 password hashing.
- **Frontend (`/frontend`)**: React 18, Vite, Tailwind CSS v4, Lucide Icons (`lucide-react`), HTML5 Canvas/Video 64-D biometric feature extraction, deterministic SVG QR code generator.

---

## Pre-Seeded Enterprise Operator Credentials

Public registration is disabled. On startup, the backend automatically seeds 3 authorized EU economic operators and 8 EV/industrial battery packs:

| Role | Email / Username | Password | Role Code |
| :--- | :--- | :--- | :--- |
| **OEM Engineer** | `oem@voltpass.eu` | `OEM-Pass-2027!` | `OEM_ADMIN` |
| **EU Compliance Auditor** | `auditor@tuv-eu.org` | `Audit-EU-77!` | `EU_AUDITOR` |
| **Second-Life Buyer** | `buyer@gridstore.de` | `Grid-Buy-88!` | `SECOND_LIFE_BUYER` |

---

## Key Features

1. **Strict RBAC & Annex XIII Data Masking (`GET /api/batteries`)**:
   - `OEM_ADMIN` and `EU_AUDITOR` see unmasked `cobalt_origin` and `audit_notes`.
   - `SECOND_LIFE_BUYER` receives `"RESTRICTED (Art. 77 Annex XIII)"` for confidential supply-chain fields.
2. **Role-Gated Workflows**:
   - `POST /api/batteries` (`OEM_ADMIN` only): Register new EV/industrial battery packs.
   - `PATCH /api/batteries/{id}/audit` (`EU_AUDITOR` only): Toggle `compliance_status` between `VERIFIED` and `FLAGGED_NON_COMPLIANT`.
   - `POST /api/batteries/{id}/evaluate-second-life`: Computes usable kWh, €95/kWh (>80% SoH) or €65/kWh (≤80% SoH) resale value, and recommended application.
   - `PATCH /api/batteries/{id}/purchase` (`SECOND_LIFE_BUYER` only): Repurposes a pack to `REPURPOSED_GRID_STORAGE` and issues a linked Second-Life Passport ID (`EU-DBP-SL-2027-xxxxxx`) under Article 77(7).
3. **Biometric Facial Scan Authentication**:
   - `OEM_ADMIN` and `EU_AUDITOR` enroll their single unique face via the Backend Admin Console (`http://localhost:8000/admin`).
   - `SECOND_LIFE_BUYER` customers self-enroll on the Frontend (`http://localhost:5173`), incrementing the registered buyer count.

---

## How to Run Locally

### 1. Start the Backend (FastAPI on Port 8000)
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```
- Backend Admin & Biometric Console: `http://localhost:8000/admin`
- Interactive Swagger API Docs: `http://localhost:8000/docs`

### 2. Start the Frontend (React + Vite on Port 5173)
```powershell
cd frontend
npm install
npm run dev -- --host 0.0.0.0 --port 5173
```
- Frontend Web App: `http://localhost:5173`
