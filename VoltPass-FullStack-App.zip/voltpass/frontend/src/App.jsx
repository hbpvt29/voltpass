import React, { useState } from 'react';
import { getStoredAuth, setStoredAuth } from './api';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';

export default function App() {
  const [auth, setAuth] = useState(() => getStoredAuth());

  const handleLoginSuccess = (authData) => {
    setStoredAuth(authData);
    setAuth(authData);
  };

  const handleLogout = () => {
    setStoredAuth(null);
    setAuth(null);
  };

  if (!auth || !auth.access_token || !auth.user) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <Dashboard
      user={auth.user}
      onLogout={handleLogout}
      onQuickRoleSwitch={handleLoginSuccess}
    />
  );
}
