import React, { useEffect, useMemo, useState } from 'react';
import {
  BatteryCharging,
  ShieldCheck,
  ShieldAlert,
  Clock,
  Search,
  Filter,
  PlusCircle,
  LogOut,
  Lock,
  Unlock,
  LayoutGrid,
  Table as TableIcon,
  Euro,
  Activity,
  Database,
  Eye,
  Factory,
  Scale,
  ShoppingCart,
  RefreshCw,
  FileBadge,
} from 'lucide-react';
import { api } from '../api';
import { DEMO_USERS } from './LoginPage';
import PassportModal from './PassportModal';
import AddBatteryModal from './AddBatteryModal';

const ROLE_META = {
  OEM_ADMIN: {
    title: 'OEM Engineer (OEM_ADMIN)',
    color: 'border-blue-500/40 bg-blue-950/40 text-blue-200',
    badge: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
    unlocked: [
      'Register new EV & industrial battery passports (POST /api/batteries)',
      'Unmasked read access to confidential Cobalt Origin & Annex XIII supply chain records',
      'Run Second-Life Valuation Calculator across all fleet units',
    ],
    restricted: [
      'Cannot toggle Notified Body EU Audit status (Restricted to EU_AUDITOR)',
      'Cannot execute Second-Life BESS purchase orders (Restricted to SECOND_LIFE_BUYER)',
    ],
  },
  EU_AUDITOR: {
    title: 'EU Compliance Auditor (EU_AUDITOR)',
    color: 'border-emerald-500/40 bg-emerald-950/40 text-emerald-200',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    unlocked: [
      'Toggle EU compliance status between VERIFIED and FLAGGED_NON_COMPLIANT (PATCH /api/batteries/{id}/audit)',
      'Unmasked inspection of Annex XIII confidential Cobalt Origin & smelter due diligence',
      'Inspect 2031 Article 8 Recycled Lithium, Cobalt & Nickel compliance targets',
    ],
    restricted: [
      'Cannot mint new OEM battery passports (Restricted to OEM_ADMIN)',
      'Cannot purchase or repurpose Second-Life packs (Restricted to SECOND_LIFE_BUYER)',
    ],
  },
  SECOND_LIFE_BUYER: {
    title: 'Second-Life BESS Buyer (SECOND_LIFE_BUYER)',
    color: 'border-amber-500/40 bg-amber-950/40 text-amber-200',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    unlocked: [
      'Purchase available packs & mint linked Second-Life Passports under Art. 77(7) (PATCH /api/batteries/{id}/purchase)',
      'Run live Second-Life Valuation Calculator (€/kWh & recommended BESS application)',
      'Inspect electrochemical SoH, internal resistance, and cycle life telemetry',
    ],
    restricted: [
      'CONFIDENTIAL FIELD MASKED: cobalt_origin & internal audit notes are redacted as "RESTRICTED (Art. 77 Annex XIII)"',
      'Cannot register new packs or modify EU Notified Body compliance statuses',
    ],
  },
};

export default function Dashboard({ user, onLogout, onQuickRoleSwitch }) {
  const [batteries, setBatteries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [chemistryFilter, setChemistryFilter] = useState('ALL');
  const [complianceFilter, setComplianceFilter] = useState('ALL');
  const [marketFilter, setMarketFilter] = useState('ALL');
  const [viewMode, setViewMode] = useState('table'); // 'table' | 'grid'
  const [selectedBattery, setSelectedBattery] = useState(null);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [switchingRole, setSwitchingRole] = useState(false);

  const fetchFleet = async () => {
    setLoading(true);
    setError('');
    try {
      const list = await api.getBatteries();
      setBatteries(list);
      if (selectedBattery) {
        const refreshed = list.find((b) => b.id === selectedBattery.id);
        if (refreshed) setSelectedBattery(refreshed);
      }
    } catch (err) {
      setError(err.message || 'Failed to load battery registry.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFleet();
  }, [user?.email]);

  const handleRoleSwitch = async (demoUser) => {
    if (demoUser.email === user.email) return;
    setSwitchingRole(true);
    try {
      const authData = await api.login(demoUser.email, demoUser.password);
      onQuickRoleSwitch(authData);
    } catch (err) {
      setError(err.message);
    } finally {
      setSwitchingRole(false);
    }
  };

  const handleBatteryUpdated = (updatedPack) => {
    setBatteries((prev) => prev.map((b) => (b.id === updatedPack.id ? updatedPack : b)));
    setSelectedBattery(updatedPack);
  };

  const handleBatteryCreated = (newPack) => {
    setBatteries((prev) => [...prev, newPack]);
    setSelectedBattery(newPack);
  };

  // Top KPI Calculations
  const kpis = useMemo(() => {
    if (!batteries.length) {
      return {
        totalMwh: '0.00',
        avgSoh: '0.0',
        verifiedCount: 0,
        totalCount: 0,
        availableSecondLifeValueEur: 0,
      };
    }

    const totalKwh = batteries.reduce((acc, b) => acc + b.nominal_capacity_kwh, 0);
    const avgSoh =
      batteries.reduce((acc, b) => acc + b.state_of_health_pct, 0) / batteries.length;
    const verifiedCount = batteries.filter((b) => b.compliance_status === 'VERIFIED').length;

    const availableSecondLifeValueEur = batteries
      .filter((b) => b.market_status === 'AVAILABLE_FOR_SECOND_LIFE')
      .reduce((acc, b) => {
        const usable = b.nominal_capacity_kwh * (b.state_of_health_pct / 100.0);
        const rate = b.state_of_health_pct > 80 ? 95 : 65;
        return acc + usable * rate;
      }, 0);

    return {
      totalMwh: (totalKwh / 1000).toFixed(2),
      avgSoh: avgSoh.toFixed(1),
      verifiedCount,
      totalCount: batteries.length,
      availableSecondLifeValueEur: Math.round(availableSecondLifeValueEur),
    };
  }, [batteries]);

  // Filtered Fleet
  const filteredBatteries = useMemo(() => {
    return batteries.filter((b) => {
      const q = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !q ||
        b.passport_id.toLowerCase().includes(q) ||
        b.model_name.toLowerCase().includes(q) ||
        b.manufacturer.toLowerCase().includes(q) ||
        (b.second_life_passport_id && b.second_life_passport_id.toLowerCase().includes(q));

      const matchesChem = chemistryFilter === 'ALL' || b.chemistry === chemistryFilter;
      const matchesComp =
        complianceFilter === 'ALL' || b.compliance_status === complianceFilter;
      const matchesMarket = marketFilter === 'ALL' || b.market_status === marketFilter;

      return matchesSearch && matchesChem && matchesComp && matchesMarket;
    });
  }, [batteries, searchQuery, chemistryFilter, complianceFilter, marketFilter]);

  const roleMeta = ROLE_META[user.role] || ROLE_META.OEM_ADMIN;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Navigation Header */}
      <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <BatteryCharging className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-white tracking-tight">VoltPass</span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-blue-500/15 text-blue-300 border border-blue-500/30">
                  EU Reg. 2023/1542 Art. 77
                </span>
              </div>
              <p className="text-xs text-slate-400">
                EU Digital Battery Passport Registry & Second-Life BESS Marketplace
              </p>
            </div>
          </div>

          {/* Right Controls: Role Indicator + Add Pack + User Profile + Logout */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                Authenticated Profile:
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold">
                {user.role}
              </span>
            </div>

            {user.role === 'OEM_ADMIN' && (
              <button
                type="button"
                onClick={() => setAddModalOpen(true)}
                className="px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-lg shadow-blue-600/25 transition cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Add Pack</span>
              </button>
            )}

            <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
              <div className="text-right hidden sm:block">
                <div className="text-xs font-semibold text-white">{user.name}</div>
                <div className="text-[11px] font-mono text-slate-400">{user.email}</div>
              </div>
              <button
                type="button"
                onClick={onLogout}
                className="p-2 rounded-lg bg-slate-800 hover:bg-rose-950/80 hover:text-rose-300 text-slate-300 border border-slate-700 transition cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-6 space-y-6">
        {/* Top KPI Bar (4 Cards) */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 font-medium">
                Total Tracked Capacity (MWh)
              </span>
              <div className="text-2xl font-bold text-white mt-1">{kpis.totalMwh} MWh</div>
              <span className="text-[11px] text-blue-400 mt-1 inline-block">
                Across {kpis.totalCount} registered EU packs
              </span>
            </div>
            <div className="h-11 w-11 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Database className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 font-medium">Average Fleet SoH %</span>
              <div className="text-2xl font-bold text-emerald-400 mt-1">{kpis.avgSoh}%</div>
              <span className="text-[11px] text-slate-400 mt-1 inline-block">
                Annex VII electrochemical telemetry
              </span>
            </div>
            <div className="h-11 w-11 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Activity className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 font-medium">EU Compliant Packs</span>
              <div className="text-2xl font-bold text-white mt-1">
                {kpis.verifiedCount}{' '}
                <span className="text-sm font-normal text-slate-400">/ {kpis.totalCount}</span>
              </div>
              <span className="text-[11px] text-emerald-400 mt-1 inline-block">
                TÜV Notified Body Verified
              </span>
            </div>
            <div className="h-11 w-11 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 font-medium">
                Available Second-Life Value €
              </span>
              <div className="text-2xl font-bold text-amber-400 mt-1">
                €{kpis.availableSecondLifeValueEur.toLocaleString()}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 inline-block">
                Ready for BESS repurposing
              </span>
            </div>
            <div className="h-11 w-11 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Euro className="w-5 h-5" />
            </div>
          </div>
        </section>

        {/* Role Banner Clearly Showing Unlocked Permissions & Restricted Data Fields */}
        <section className={`rounded-xl border p-4 ${roleMeta.color}`}>
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2.5">
              <span
                className={`px-2.5 py-0.5 rounded-md text-xs font-mono font-bold border ${roleMeta.badge}`}
              >
                ACTIVE ROLE: {user.role}
              </span>
              <h2 className="text-sm font-bold text-white">
                {roleMeta.title} — Article 77 & Annex XIII Access Matrix
              </h2>
            </div>
            <span className="text-xs text-slate-300">{user.organization}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
              <div className="font-semibold text-emerald-300 flex items-center gap-1.5 mb-1.5">
                <Unlock className="w-3.5 h-3.5" />
                Unlocked Permissions & Visible Fields
              </div>
              <ul className="space-y-1 text-slate-300 list-disc list-inside">
                {roleMeta.unlocked.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
              <div className="font-semibold text-amber-300 flex items-center gap-1.5 mb-1.5">
                <Lock className="w-3.5 h-3.5" />
                Restricted Actions & Masked Fields (RBAC Enforced)
              </div>
              <ul className="space-y-1 text-slate-300 list-disc list-inside">
                {roleMeta.restricted.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* Search & Filter Controls Bar */}
        <section className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[260px]">
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by Passport ID, Model, or OEM..."
                className="w-full pl-9 pr-4 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Chemistry Filter */}
            <div className="flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={chemistryFilter}
                onChange={(e) => setChemistryFilter(e.target.value)}
                className="px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-slate-200"
              >
                <option value="ALL">All Chemistries</option>
                <option value="NMC-811">NMC-811</option>
                <option value="LFP">LFP</option>
                <option value="NCA">NCA</option>
              </select>
            </div>

            {/* Compliance Status Filter */}
            <select
              value={complianceFilter}
              onChange={(e) => setComplianceFilter(e.target.value)}
              className="px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-slate-200"
            >
              <option value="ALL">All Compliance Statuses</option>
              <option value="VERIFIED">VERIFIED</option>
              <option value="PENDING_AUDIT">PENDING_AUDIT</option>
              <option value="FLAGGED_NON_COMPLIANT">FLAGGED_NON_COMPLIANT</option>
            </select>

            {/* Market Status Filter */}
            <select
              value={marketFilter}
              onChange={(e) => setMarketFilter(e.target.value)}
              className="px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-slate-200"
            >
              <option value="ALL">All Market States</option>
              <option value="AVAILABLE_FOR_SECOND_LIFE">AVAILABLE_FOR_SECOND_LIFE</option>
              <option value="IN_VEHICLE">IN_VEHICLE</option>
              <option value="REPURPOSED_GRID_STORAGE">REPURPOSED_GRID_STORAGE</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={fetchFleet}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer"
              title="Refresh Registry"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>

            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-1">
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`px-2.5 py-1 rounded text-xs flex items-center gap-1 cursor-pointer ${
                  viewMode === 'table'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <TableIcon className="w-3.5 h-3.5" />
                Table
              </button>
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`px-2.5 py-1 rounded text-xs flex items-center gap-1 cursor-pointer ${
                  viewMode === 'grid'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                Grid
              </button>
            </div>
          </div>
        </section>

        {error && (
          <div className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200">
            {error}
          </div>
        )}

        {/* Fleet Display: Table or Grid */}
        {viewMode === 'table' ? (
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/70 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                    <th className="py-3.5 px-4">Passport ID</th>
                    <th className="py-3.5 px-4">Battery Model & OEM</th>
                    <th className="py-3.5 px-3">Chem</th>
                    <th className="py-3.5 px-3">Capacity</th>
                    <th className="py-3.5 px-3">SoH & Cycles</th>
                    <th className="py-3.5 px-4">Cobalt Origin (Annex XIII)</th>
                    <th className="py-3.5 px-3">Recycled Li</th>
                    <th className="py-3.5 px-3">EU Audit</th>
                    <th className="py-3.5 px-3">Market Status</th>
                    <th className="py-3.5 px-4 text-right">Passport</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70 text-xs">
                  {filteredBatteries.map((b) => {
                    const isMasked = b.cobalt_origin?.includes('RESTRICTED');
                    return (
                      <tr
                        key={b.id}
                        onClick={() => setSelectedBattery(b)}
                        className="hover:bg-slate-800/50 transition cursor-pointer"
                      >
                        <td className="py-3.5 px-4 font-mono font-semibold text-blue-300 whitespace-nowrap">
                          <div>{b.passport_id}</div>
                          {b.second_life_passport_id && (
                            <div className="text-[10px] text-purple-300 flex items-center gap-1 mt-0.5">
                              <FileBadge className="w-3 h-3" />
                              {b.second_life_passport_id}
                            </div>
                          )}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-white">{b.model_name}</div>
                          <div className="text-[11px] text-slate-400">{b.manufacturer}</div>
                        </td>
                        <td className="py-3.5 px-3">
                          <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono text-[11px] text-slate-200">
                            {b.chemistry}
                          </span>
                        </td>
                        <td className="py-3.5 px-3 font-mono text-slate-200">
                          {b.nominal_capacity_kwh} kWh
                        </td>
                        <td className="py-3.5 px-3">
                          <div className="flex items-center gap-2">
                            <span
                              className={`font-bold ${
                                b.state_of_health_pct >= 80
                                  ? 'text-emerald-400'
                                  : b.state_of_health_pct >= 70
                                  ? 'text-amber-400'
                                  : 'text-rose-400'
                              }`}
                            >
                              {b.state_of_health_pct}%
                            </span>
                            <span className="text-[11px] text-slate-400">
                              ({b.charge_cycles} cyc)
                            </span>
                          </div>
                          <div className="w-24 h-1.5 bg-slate-800 rounded-full mt-1 overflow-hidden">
                            <div
                              className={`h-full ${
                                b.state_of_health_pct >= 80
                                  ? 'bg-emerald-500'
                                  : b.state_of_health_pct >= 70
                                  ? 'bg-amber-500'
                                  : 'bg-rose-500'
                              }`}
                              style={{ width: `${b.state_of_health_pct}%` }}
                            />
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          {isMasked ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/15 border border-amber-500/30 text-amber-300 font-mono text-[11px]">
                              <Lock className="w-3 h-3" />
                              {b.cobalt_origin}
                            </span>
                          ) : (
                            <span className="text-slate-200 font-medium">{b.cobalt_origin}</span>
                          )}
                        </td>
                        <td className="py-3.5 px-3 font-mono">
                          <span
                            className={
                              b.recycled_lithium_pct >= 6
                                ? 'text-emerald-400 font-semibold'
                                : 'text-rose-400 font-semibold'
                            }
                          >
                            {b.recycled_lithium_pct}%
                          </span>
                        </td>
                        <td className="py-3.5 px-3">
                          {b.compliance_status === 'VERIFIED' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-medium">
                              <ShieldCheck className="w-3 h-3" />
                              VERIFIED
                            </span>
                          )}
                          {b.compliance_status === 'PENDING_AUDIT' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] font-medium">
                              <Clock className="w-3 h-3" />
                              PENDING
                            </span>
                          )}
                          {b.compliance_status === 'FLAGGED_NON_COMPLIANT' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[11px] font-medium">
                              <ShieldAlert className="w-3 h-3" />
                              FLAGGED
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-3">
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                              b.market_status === 'AVAILABLE_FOR_SECOND_LIFE'
                                ? 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
                                : b.market_status === 'REPURPOSED_GRID_STORAGE'
                                ? 'bg-purple-500/15 text-purple-300 border border-purple-500/30'
                                : 'bg-slate-800 text-slate-300 border border-slate-700'
                            }`}
                          >
                            {b.market_status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedBattery(b);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600 text-blue-300 hover:text-white border border-blue-500/30 text-xs font-medium inline-flex items-center gap-1 transition cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            Inspect
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          /* Card Grid View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredBatteries.map((b) => {
              const isMasked = b.cobalt_origin?.includes('RESTRICTED');
              return (
                <div
                  key={b.id}
                  onClick={() => setSelectedBattery(b)}
                  className="bg-slate-900/90 border border-slate-800 hover:border-blue-500/50 rounded-xl p-5 flex flex-col justify-between transition cursor-pointer shadow-lg"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="font-mono text-xs font-bold text-blue-300">
                        {b.passport_id}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono text-[11px] text-slate-200">
                        {b.chemistry} • {b.nominal_capacity_kwh} kWh
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white mb-1">{b.model_name}</h3>
                    <p className="text-xs text-slate-400 mb-4">{b.manufacturer}</p>

                    <div className="space-y-2 text-xs mb-4">
                      <div className="flex justify-between">
                        <span className="text-slate-400">State of Health:</span>
                        <span className="font-bold text-emerald-400">
                          {b.state_of_health_pct}% ({b.charge_cycles} cycles)
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Carbon Footprint:</span>
                        <span className="font-mono text-slate-200">
                          {b.carbon_footprint_kg_per_kwh} kg CO₂e/kWh
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Cobalt Origin:</span>
                        <span
                          className={`font-mono text-[11px] truncate max-w-[180px] ${
                            isMasked ? 'text-amber-300' : 'text-slate-200'
                          }`}
                        >
                          {b.cobalt_origin}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                    <span className="text-[11px] font-medium text-slate-300">
                      {b.compliance_status}
                    </span>
                    <span className="text-xs font-semibold text-blue-400 flex items-center gap-1">
                      Open Digital Passport →
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Interactive Digital Passport Modal */}
      {selectedBattery && (
        <PassportModal
          battery={selectedBattery}
          user={user}
          onClose={() => setSelectedBattery(null)}
          onBatteryUpdated={handleBatteryUpdated}
          onOpenAddModal={() => setAddModalOpen(true)}
        />
      )}

      {/* OEM Add Battery Modal */}
      <AddBatteryModal
        isOpen={addModalOpen}
        onClose={() => setAddModalOpen(false)}
        onCreated={handleBatteryCreated}
      />
    </div>
  );
}
