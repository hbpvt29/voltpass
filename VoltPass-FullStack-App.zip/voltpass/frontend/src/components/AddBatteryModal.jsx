import React, { useState } from 'react';
import { X, PlusCircle, BatteryCharging, ShieldCheck } from 'lucide-react';
import { api } from '../api';

export default function AddBatteryModal({ isOpen, onClose, onCreated }) {
  const [form, setForm] = useState({
    model_name: 'Audi Q6 e-tron PPE Performance Pack',
    manufacturer: 'Audi AG / Ingolstadt Battery Assembly',
    manufacturing_date: '2026-10-15',
    chemistry: 'NMC-811',
    nominal_capacity_kwh: 100.0,
    state_of_health_pct: 91.5,
    charge_cycles: 410,
    internal_resistance_mohm: 39.4,
    carbon_footprint_kg_per_kwh: 56.8,
    cobalt_origin: 'Morocco - Certified Managem Group Responsible Mining',
    recycled_cobalt_pct: 19.5,
    recycled_lithium_pct: 11.0,
    recycled_nickel_pct: 10.5,
    compliance_status: 'VERIFIED',
    market_status: 'AVAILABLE_FOR_SECOND_LIFE',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const payload = {
        ...form,
        nominal_capacity_kwh: parseFloat(form.nominal_capacity_kwh),
        state_of_health_pct: parseFloat(form.state_of_health_pct),
        charge_cycles: parseInt(form.charge_cycles, 10),
        internal_resistance_mohm: parseFloat(form.internal_resistance_mohm),
        carbon_footprint_kg_per_kwh: parseFloat(form.carbon_footprint_kg_per_kwh),
        recycled_cobalt_pct: parseFloat(form.recycled_cobalt_pct),
        recycled_lithium_pct: parseFloat(form.recycled_lithium_pct),
        recycled_nickel_pct: parseFloat(form.recycled_nickel_pct),
      };
      const created = await api.createBattery(payload);
      onCreated(created);
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to create battery passport.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden my-8">
        <div className="bg-slate-950 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <BatteryCharging className="w-5 h-5 text-blue-400" />
            <div>
              <h2 className="text-base font-bold text-white">
                Register New EU Digital Battery Passport (OEM_ADMIN)
              </h2>
              <p className="text-xs text-slate-400">
                Submits mandatory Article 77 & Annex XIII telemetry and origin declaration
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs">
          {error && (
            <div className="p-3 rounded-lg bg-rose-950/70 border border-rose-500/40 text-rose-200">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Battery Model Name</label>
              <input
                type="text"
                required
                value={form.model_name}
                onChange={(e) => handleChange('model_name', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">OEM Manufacturer</label>
              <input
                type="text"
                required
                value={form.manufacturer}
                onChange={(e) => handleChange('manufacturer', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Cathode Chemistry</label>
              <select
                value={form.chemistry}
                onChange={(e) => handleChange('chemistry', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              >
                <option value="NMC-811">NMC-811</option>
                <option value="LFP">LFP</option>
                <option value="NCA">NCA</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Nominal Capacity (kWh)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={form.nominal_capacity_kwh}
                onChange={(e) => handleChange('nominal_capacity_kwh', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">
                State of Health (SoH %)
              </label>
              <input
                type="number"
                step="0.1"
                min="10"
                max="100"
                required
                value={form.state_of_health_pct}
                onChange={(e) => handleChange('state_of_health_pct', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Charge Cycles</label>
              <input
                type="number"
                required
                value={form.charge_cycles}
                onChange={(e) => handleChange('charge_cycles', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Internal Resistance (mΩ)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={form.internal_resistance_mohm}
                onChange={(e) => handleChange('internal_resistance_mohm', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Carbon Footprint (kg CO₂e/kWh)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={form.carbon_footprint_kg_per_kwh}
                onChange={(e) => handleChange('carbon_footprint_kg_per_kwh', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-blue-300 font-semibold mb-1">
                Confidential Cobalt Origin (Art. 77 Annex XIII — Masked for Buyers)
              </label>
              <input
                type="text"
                required
                value={form.cobalt_origin}
                onChange={(e) => handleChange('cobalt_origin', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-blue-500/50 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Recycled Lithium (%) [2031 Target: 6%]
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={form.recycled_lithium_pct}
                onChange={(e) => handleChange('recycled_lithium_pct', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Market Availability</label>
              <select
                value={form.market_status}
                onChange={(e) => handleChange('market_status', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              >
                <option value="AVAILABLE_FOR_SECOND_LIFE">AVAILABLE_FOR_SECOND_LIFE</option>
                <option value="IN_VEHICLE">IN_VEHICLE</option>
              </select>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold flex items-center gap-1.5 shadow-lg shadow-blue-600/25 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{loading ? 'Minting Passport...' : 'Mint EU Battery Passport'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
