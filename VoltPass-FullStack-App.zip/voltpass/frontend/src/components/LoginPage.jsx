import React, { useState } from 'react';
import {
  ShieldAlert,
  Lock,
  BatteryCharging,
  CheckCircle2,
  UserCheck,
  Factory,
  Scale,
  ShoppingCart,
  ArrowRight,
  KeyRound,
  Mail,
  Sparkles,
  ScanFace,
} from 'lucide-react';
import { api } from '../api';
import FaceScanAuth from './FaceScanAuth';

export const DEMO_USERS = [
  {
    label: 'OEM Engineer',
    role: 'OEM_ADMIN',
    email: 'oem@voltpass.eu',
    password: 'OEM-Pass-2027!',
    org: 'Porsche AG / VW PowerCo',
    badgeColor: 'border-blue-500/40 bg-blue-500/10 text-blue-300 hover:bg-blue-500/20',
    icon: Factory,
    desc: 'Add new battery packs & view unmasked Annex XIII cobalt origin',
  },
  {
    label: 'EU Compliance Auditor',
    role: 'EU_AUDITOR',
    email: 'auditor@tuv-eu.org',
    password: 'Audit-EU-77!',
    org: 'TÜV Rheinland Notified Body #0197',
    badgeColor: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20',
    icon: Scale,
    desc: 'Audit supply chain records & toggle VERIFIED / FLAGGED status',
  },
  {
    label: 'Second-Life Buyer',
    role: 'SECOND_LIFE_BUYER',
    email: 'buyer@gridstore.de',
    password: 'Grid-Buy-88!',
    org: 'GridStore DE BESS Procurement',
    badgeColor: 'border-amber-500/40 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20',
    icon: ShoppingCart,
    desc: 'Confidential origin masked (Art. 77) • Evaluate & purchase packs',
  },
];

export default function LoginPage({ onLoginSuccess }) {
  const [authMode, setAuthMode] = useState('password'); // 'password' | 'facescan'
  const [email, setEmail] = useState('oem@voltpass.eu');
  const [password, setPassword] = useState('OEM-Pass-2027!');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    if (e) e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data = await api.login(email, password);
      onLoginSuccess(data);
    } catch (err) {
      setError(err.message || 'Authentication failed. Check credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickFill = (demoUser) => {
    setEmail(demoUser.email);
    setPassword(demoUser.password);
    setError('');
  };

  const handleQuickSignIn = async (demoUser) => {
    setEmail(demoUser.email);
    setPassword(demoUser.password);
    setError('');
    setLoading(true);
    try {
      const data = await api.login(demoUser.email, demoUser.password);
      onLoginSuccess(data);
    } catch (err) {
      setError(err.message || 'Authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between relative overflow-hidden">
      {/* Subtle grid background */}
      <div
        className="pointer-events-none absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            'radial-gradient(circle at 20% 20%, rgba(59, 130, 246, 0.25), transparent 45%), radial-gradient(circle at 80% 80%, rgba(16, 185, 129, 0.2), transparent 45%)',
        }}
      />

      {/* Top Regulatory Bar */}
      <header className="relative z-10 border-b border-slate-800/80 bg-slate-900/70 backdrop-blur-md px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <BatteryCharging className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold tracking-tight text-white text-lg">VoltPass</span>
                <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  EU Reg. 2023/1542 • Art. 77
                </span>
              </div>
              <p className="text-xs text-slate-400">
                European Digital Battery Passport Registry & Second-Life BESS Clearinghouse
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-amber-300 bg-amber-500/10 border border-amber-500/30 px-3 py-1.5 rounded-full">
            <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
            <span className="font-medium">
              Restricted Portal - Authorized EU Economic Operators Only
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl">
          {/* Left Column: EU Regulatory Overview */}
          <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950/60 p-8 border-b lg:border-b-0 lg:border-r border-slate-800 flex flex-col justify-between">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-medium mb-6">
                <Lock className="w-3.5 h-3.5" />
                Annex XIII Granular Access Control
              </div>

              <h1 className="text-2xl font-bold text-white tracking-tight leading-snug mb-3">
                Digital Battery Passport & Second-Life Marketplace
              </h1>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                Mandatory sovereign traceability for EV & industrial traction batteries &gt; 2 kWh entering the European Economic Area.
              </p>

              <div className="space-y-3.5 text-xs text-slate-300">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white">Biometric Facial Scan & Passkey Gate:</span> Operators can authenticate via live optical 64-D facial feature verification or password credentials.
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white">Article 77 & Annex XIII RBAC:</span> Confidential raw mineral origin (<code className="text-blue-300">cobalt_origin</code>) is visible to OEMs & Notified Body Auditors, and automatically masked for Second-Life Buyers.
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white">Article 77(7) Repurposing:</span> Automated Second-Life valuation (€/kWh) and linked Passport ID issuance upon stationary BESS acquisition.
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
              <span>No Public Registration Permitted</span>
              <span>eIDAS Biometric • JWT RBAC</span>
            </div>
          </div>

          {/* Right Column: Login Form / Biometric Scanner */}
          <div className="lg:col-span-7 p-8 flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-5">
                <div>
                  <h2 className="text-xl font-bold text-white">Operator Authentication</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Sign in via Password Credentials or Biometric Facial Scan
                  </p>
                </div>

                {/* Mode Switcher Tabs: Password vs Biometric Facial Scan */}
                <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl p-1">
                  <button
                    type="button"
                    onClick={() => setAuthMode('password')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                      authMode === 'password'
                        ? 'bg-blue-600 text-white shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    Passkey
                  </button>
                  <button
                    type="button"
                    onClick={() => setAuthMode('facescan')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                      authMode === 'facescan'
                        ? 'bg-emerald-600 text-white shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <ScanFace className="w-3.5 h-3.5" />
                    Facial Scan
                  </button>
                </div>
              </div>

              {/* Security Notice Banner inside Card */}
              <div className="mb-4 p-3 rounded-lg bg-amber-950/40 border border-amber-500/30 flex items-center gap-2.5 text-xs text-amber-200">
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  <strong>Restricted Portal - Authorized EU Economic Operators Only.</strong> Public sign-up is strictly disabled per EU Commission security policy.
                </span>
              </div>

              {authMode === 'facescan' ? (
                <FaceScanAuth
                  onLoginSuccess={onLoginSuccess}
                  selectedOperatorEmail={email}
                  onSelectOperator={(demoUser) => {
                    setEmail(demoUser.email);
                    setPassword(demoUser.password);
                  }}
                />
              ) : (
                <>
                  {error && (
                    <div className="mb-4 p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Operator Email Address
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="operator@voltpass.eu"
                          className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Security Passkey / Password
                      </label>
                      <div className="relative">
                        <KeyRound className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="password"
                          required
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="••••••••••••"
                          className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <button
                        type="submit"
                        disabled={loading}
                        className="py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-semibold text-xs shadow-lg shadow-blue-600/25 transition flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <UserCheck className="w-4 h-4" />
                        <span>{loading ? 'Authenticating...' : 'Sign In with Password'}</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => setAuthMode('facescan')}
                        className="py-2.5 px-4 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 font-semibold text-xs transition flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <ScanFace className="w-4 h-4" />
                        <span>Use Biometric Facial Scan</span>
                      </button>
                    </div>
                  </form>

                  {/* 3 Quick Fill Demo Credentials Buttons */}
                  <div className="mt-7 pt-5 border-t border-slate-800">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                        Quick Fill Demo Credentials (1-Click Evaluator Access)
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {DEMO_USERS.map((u) => {
                        const Icon = u.icon;
                        const isSelected = email.toLowerCase() === u.email.toLowerCase();
                        return (
                          <div
                            key={u.role}
                            className={`rounded-xl border p-3 transition flex flex-col justify-between ${
                              isSelected
                                ? 'border-blue-500 bg-blue-500/15 shadow-sm'
                                : 'border-slate-800 bg-slate-950/70 hover:border-slate-700'
                            }`}
                          >
                            <div>
                              <div className="flex items-center justify-between gap-1 mb-1">
                                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                                  <Icon className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                                  {u.label}
                                </span>
                              </div>
                              <div className="text-[11px] font-mono text-blue-300 truncate">
                                {u.email}
                              </div>
                              <p className="text-[10px] text-slate-400 mt-1 leading-tight">
                                {u.desc}
                              </p>
                            </div>

                            <div className="mt-2.5 flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleQuickFill(u)}
                                className="flex-1 py-1 px-2 rounded bg-slate-800 hover:bg-slate-700 text-[11px] font-medium text-slate-200 transition cursor-pointer"
                              >
                                Quick Fill
                              </button>
                              <button
                                type="button"
                                onClick={() => handleQuickSignIn(u)}
                                className="py-1 px-2 rounded bg-blue-600/80 hover:bg-blue-500 text-[11px] font-semibold text-white transition cursor-pointer"
                                title="Fill and Sign In Immediately"
                              >
                                Login →
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </main>

      <footer className="relative z-10 text-center py-3 text-xs text-slate-500 border-t border-slate-900">
        VoltPass EU Sovereign Battery Registry • Compliant with Regulation (EU) 2023/1542 Article 77 & Annex XIII
      </footer>
    </div>
  );
}
