import React, { useEffect, useState } from 'react';
import {
  X,
  QrCode,
  ShieldCheck,
  ShieldAlert,
  Clock,
  BatteryCharging,
  Activity,
  Zap,
  Leaf,
  Lock,
  Unlock,
  Calculator,
  ShoppingCart,
  CheckCircle2,
  AlertTriangle,
  FileBadge,
  Factory,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { api } from '../api';

/**
 * Deterministic SVG QR Code Generator
 * Produces an authentic QR-style matrix with finder patterns, timing patterns,
 * and deterministic data cells seeded from the battery passport ID.
 */
function PassportQRCodeSVG({ value, size = 148 }) {
  const gridSize = 25;

  // Hash string deterministically
  let hash = 2166136261;
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }

  const isFinderArea = (r, c) => {
    if (r < 8 && c < 8) return true;
    if (r < 8 && c >= gridSize - 8) return true;
    if (r >= gridSize - 8 && c < 8) return true;
    return false;
  };

  const isFinderDark = (r, c, topR, leftC) => {
    const lr = r - topR;
    const lc = c - leftC;
    if (lr < 0 || lr > 6 || lc < 0 || lc > 6) return false;
    if (lr === 0 || lr === 6 || lc === 0 || lc === 6) return true;
    if (lr >= 2 && lr <= 4 && lc >= 2 && lc <= 4) return true;
    return false;
  };

  const cells = [];
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      let dark = false;
      if (isFinderArea(r, c)) {
        dark =
          isFinderDark(r, c, 0, 0) ||
          isFinderDark(r, c, 0, gridSize - 7) ||
          isFinderDark(r, c, gridSize - 7, 0);
      } else if (r === 6 || c === 6) {
        // Timing pattern
        dark = (r + c) % 2 === 0;
      } else {
        // Deterministic bit from passport_id + coordinates
        const charCode = value.charCodeAt((r * gridSize + c) % value.length);
        const mix = ((r * 31 + c * 17 + charCode * 13) ^ (hash >>> ((r + c) % 16))) & 0xff;
        dark = mix % 2 === 0 || mix % 5 === 0;
      }

      if (dark) {
        cells.push(<rect key={`${r}-${c}`} x={c + 2} y={r + 2} width={1} height={1} fill="#0f172a" />);
      }
    }
  }

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${gridSize + 4} ${gridSize + 4}`}
      className="rounded-xl bg-white p-1.5 shadow-inner border border-slate-300"
      aria-label={`QR Code for ${value}`}
    >
      <rect x="0" y="0" width={gridSize + 4} height={gridSize + 4} fill="#ffffff" rx="1.5" />
      {cells}
    </svg>
  );
}

export default function PassportModal({
  battery,
  user,
  onClose,
  onBatteryUpdated,
  onOpenAddModal,
}) {
  const [evaluation, setEvaluation] = useState(null);
  const [evalLoading, setEvalLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionMessage, setActionMessage] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);

  useEffect(() => {
    if (!battery) return;
    let active = true;
    setEvalLoading(true);
    setActionMessage(null);
    setErrorMessage(null);

    api
      .evaluateSecondLife(battery.id)
      .then((res) => {
        if (active) setEvaluation(res);
      })
      .catch((err) => {
        if (active) setErrorMessage(err.message);
      })
      .finally(() => {
        if (active) setEvalLoading(false);
      });

    return () => {
      active = false;
    };
  }, [battery]);

  if (!battery) return null;

  const isRestrictedOrigin = battery.cobalt_origin?.includes('RESTRICTED');

  const handleAuditToggle = async () => {
    setActionLoading(true);
    setErrorMessage(null);
    setActionMessage(null);
    try {
      const updated = await api.auditBattery(battery.id);
      onBatteryUpdated(updated);
      setActionMessage(
        `EU Compliance status updated to ${updated.compliance_status} by Notified Body Auditor.`
      );
    } catch (err) {
      setErrorMessage(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handlePurchase = async () => {
    setActionLoading(true);
    setErrorMessage(null);
    setActionMessage(null);
    try {
      const updated = await api.purchaseBattery(battery.id);
      onBatteryUpdated(updated);
      setActionMessage(
        `Second-Life acquisition complete! Linked Passport ${updated.second_life_passport_id} issued under Art. 77(7).`
      );
    } catch (err) {
      setErrorMessage(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // EU 2031 Targets (Article 8): Lithium 6%, Cobalt 16%, Nickel 6%
  const liTarget = 6.0;
  const coTarget = 16.0;
  const niTarget = 6.0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Top EU Official Header Banner */}
        <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-blue-600/20 border border-blue-400/40 flex items-center justify-center text-blue-400 font-bold">
              EU
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-widest text-blue-400">
                  Official EU Digital Battery Passport
                </span>
                <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-mono">
                  Reg. (EU) 2023/1542 • Art. 77
                </span>
              </div>
              <h2 className="text-lg font-bold text-white mt-0.5">{battery.model_name}</h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-6 max-h-[82vh] overflow-y-auto">
          {actionMessage && (
            <div className="p-3.5 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="font-medium">{actionMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span className="font-medium">{errorMessage}</span>
            </div>
          )}

          {/* Top Row: QR Code + Identity Metadata */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 bg-slate-950/60 border border-slate-800 rounded-xl p-5">
            <div className="md:col-span-4 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-slate-800 pb-4 md:pb-0 md:pr-4">
              <PassportQRCodeSVG
                value={battery.second_life_passport_id || battery.passport_id}
                size={136}
              />
              <div className="mt-2.5 text-center">
                <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1">
                  <QrCode className="w-3.5 h-3.5 text-blue-400" />
                  <span>ISO/IEC 18004 SVG Data Carrier</span>
                </div>
                <div className="text-xs font-mono font-bold text-white mt-0.5">
                  {battery.passport_id}
                </div>
                {battery.second_life_passport_id && (
                  <div className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded bg-purple-500/20 border border-purple-500/40 text-[11px] font-mono text-purple-300">
                    <FileBadge className="w-3 h-3" />
                    2nd-Life: {battery.second_life_passport_id}
                  </div>
                )}
              </div>
            </div>

            <div className="md:col-span-8 flex flex-col justify-between space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-md bg-blue-500/15 border border-blue-500/30 text-blue-300 text-xs font-semibold">
                    Chemistry: {battery.chemistry}
                  </span>
                  <span className="px-2.5 py-1 rounded-md bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold">
                    Nominal: {battery.nominal_capacity_kwh} kWh
                  </span>
                </div>

                {/* Compliance Badge */}
                {battery.compliance_status === 'VERIFIED' && (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs font-semibold">
                    <ShieldCheck className="w-4 h-4" />
                    VERIFIED COMPLIANT
                  </span>
                )}
                {battery.compliance_status === 'PENDING_AUDIT' && (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs font-semibold">
                    <Clock className="w-4 h-4" />
                    PENDING AUDIT
                  </span>
                )}
                {battery.compliance_status === 'FLAGGED_NON_COMPLIANT' && (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs font-semibold">
                    <ShieldAlert className="w-4 h-4" />
                    FLAGGED NON-COMPLIANT
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/90">
                  <div className="text-slate-400 flex items-center gap-1.5 mb-1">
                    <Factory className="w-3.5 h-3.5 text-slate-500" />
                    Economic Operator / Manufacturer
                  </div>
                  <div className="font-semibold text-white">{battery.manufacturer}</div>
                </div>

                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/90">
                  <div className="text-slate-400 flex items-center gap-1.5 mb-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    Market Placement & Lifecycle State
                  </div>
                  <div className="font-semibold text-white">
                    {battery.manufacturing_date} •{' '}
                    <span className="text-blue-300">{battery.market_status.replaceAll('_', ' ')}</span>
                  </div>
                </div>
              </div>

              {/* Annex XIII Supply Chain Confidential Block */}
              <div
                className={`p-3.5 rounded-xl border ${
                  isRestrictedOrigin
                    ? 'bg-amber-950/25 border-amber-500/40'
                    : 'bg-slate-900/90 border-emerald-500/30'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                    {isRestrictedOrigin ? (
                      <>
                        <Lock className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-amber-300">
                          Annex XIII Section 2 Confidential Supply Chain Data
                        </span>
                      </>
                    ) : (
                      <>
                        <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-300">
                          Annex XIII Section 2 Authorized Disclosure ({user.role})
                        </span>
                      </>
                    )}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs mt-2">
                  <div>
                    <span className="text-slate-400 block">Cobalt Raw Material Origin:</span>
                    <span
                      className={`font-mono font-semibold ${
                        isRestrictedOrigin ? 'text-amber-300' : 'text-white'
                      }`}
                    >
                      {battery.cobalt_origin}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Notified Body Audit Log:</span>
                    <span
                      className={`font-medium ${
                        isRestrictedOrigin ? 'font-mono text-amber-300' : 'text-slate-200'
                      }`}
                    >
                      {battery.audit_notes}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Middle Row: Health Telemetry Bars & ESG Recycled Content vs 2031 EU Targets */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Health Telemetry */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-400" />
                  Electrochemical Health Telemetry
                </h3>
                <span className="text-[11px] text-slate-400">Annex VII Parameters</span>
              </div>

              {/* SoH Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">State of Health (SoH)</span>
                  <span
                    className={`font-bold ${
                      battery.state_of_health_pct >= 80
                        ? 'text-emerald-400'
                        : battery.state_of_health_pct >= 70
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {battery.state_of_health_pct}%
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      battery.state_of_health_pct >= 80
                        ? 'bg-emerald-500'
                        : battery.state_of_health_pct >= 70
                        ? 'bg-amber-500'
                        : 'bg-rose-500'
                    }`}
                    style={{ width: `${Math.min(100, battery.state_of_health_pct)}%` }}
                  />
                </div>
              </div>

              {/* Charge Cycles Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Full Equivalent Charge Cycles</span>
                  <span className="font-mono font-semibold text-white">
                    {battery.charge_cycles} / 3,000 cycles
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500 rounded-full"
                    style={{ width: `${Math.min(100, (battery.charge_cycles / 3000) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Internal Resistance Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Pack Internal Resistance (DCIR)</span>
                  <span className="font-mono font-semibold text-white">
                    {battery.internal_resistance_mohm} mΩ
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      battery.internal_resistance_mohm < 55 ? 'bg-cyan-400' : 'bg-amber-400'
                    }`}
                    style={{
                      width: `${Math.min(100, (battery.internal_resistance_mohm / 100) * 100)}%`,
                    }}
                  />
                </div>
              </div>

              {/* Carbon Footprint */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Lifecycle Carbon Footprint (Art. 7)</span>
                  <span className="font-mono font-semibold text-emerald-300">
                    {battery.carbon_footprint_kg_per_kwh} kg CO₂e / kWh
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      battery.carbon_footprint_kg_per_kwh <= 70 ? 'bg-emerald-500' : 'bg-rose-500'
                    }`}
                    style={{
                      width: `${Math.min(100, (battery.carbon_footprint_kg_per_kwh / 110) * 100)}%`,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* ESG Recycled Content vs 2031 EU Targets */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Leaf className="w-4 h-4 text-emerald-400" />
                  ESG Recycled Content vs. 2031 EU Targets
                </h3>
                <span className="text-[11px] text-slate-400">Article 8 Mandates</span>
              </div>

              {/* Recycled Lithium vs 6% Target */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Recycled Lithium (2031 Target: 6.0%)</span>
                  <span
                    className={`font-mono font-bold ${
                      battery.recycled_lithium_pct >= liTarget
                        ? 'text-emerald-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {battery.recycled_lithium_pct}%{' '}
                    {battery.recycled_lithium_pct >= liTarget ? '✓ Meets 2031' : '✗ Below 6%'}
                  </span>
                </div>
                <div className="relative w-full h-3 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      battery.recycled_lithium_pct >= liTarget ? 'bg-emerald-500' : 'bg-rose-500'
                    }`}
                    style={{ width: `${Math.min(100, (battery.recycled_lithium_pct / 24) * 100)}%` }}
                  />
                  {/* Target Marker Line at 6/24 = 25% */}
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-white"
                    style={{ left: '25%' }}
                    title="2031 EU Minimum Target: 6%"
                  />
                </div>
              </div>

              {/* Recycled Cobalt vs 16% Target */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Recycled Cobalt (2031 Target: 16.0%)</span>
                  <span
                    className={`font-mono font-bold ${
                      battery.chemistry === 'LFP' || battery.recycled_cobalt_pct >= coTarget
                        ? 'text-emerald-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {battery.chemistry === 'LFP'
                      ? '0% (Co-Free LFP Exempt)'
                      : `${battery.recycled_cobalt_pct}% ${
                          battery.recycled_cobalt_pct >= coTarget ? '✓ Meets 2031' : '✗ Below 16%'
                        }`}
                  </span>
                </div>
                <div className="relative w-full h-3 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      battery.chemistry === 'LFP' || battery.recycled_cobalt_pct >= coTarget
                        ? 'bg-emerald-500'
                        : 'bg-rose-500'
                    }`}
                    style={{
                      width:
                        battery.chemistry === 'LFP'
                          ? '100%'
                          : `${Math.min(100, (battery.recycled_cobalt_pct / 32) * 100)}%`,
                    }}
                  />
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-white"
                    style={{ left: '50%' }}
                    title="2031 EU Minimum Target: 16%"
                  />
                </div>
              </div>

              {/* Recycled Nickel vs 6% Target */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Recycled Nickel (2031 Target: 6.0%)</span>
                  <span
                    className={`font-mono font-bold ${
                      battery.chemistry === 'LFP' || battery.recycled_nickel_pct >= niTarget
                        ? 'text-emerald-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {battery.chemistry === 'LFP'
                      ? '0% (Ni-Free LFP Exempt)'
                      : `${battery.recycled_nickel_pct}% ${
                          battery.recycled_nickel_pct >= niTarget ? '✓ Meets 2031' : '✗ Below 6%'
                        }`}
                  </span>
                </div>
                <div className="relative w-full h-3 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      battery.chemistry === 'LFP' || battery.recycled_nickel_pct >= niTarget
                        ? 'bg-emerald-500'
                        : 'bg-rose-500'
                    }`}
                    style={{
                      width:
                        battery.chemistry === 'LFP'
                          ? '100%'
                          : `${Math.min(100, (battery.recycled_nickel_pct / 24) * 100)}%`,
                    }}
                  />
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-white"
                    style={{ left: '25%' }}
                    title="2031 EU Minimum Target: 6%"
                  />
                </div>
              </div>

              <p className="text-[11px] text-slate-400 pt-1">
                White vertical markers denote mandatory EU 2031 circularity thresholds under Article 8(2).
              </p>
            </div>
          </div>

          {/* Bottom Section: Second-Life Valuation Calculator */}
          <div className="bg-gradient-to-r from-slate-950 via-blue-950/30 to-slate-950 border border-blue-500/30 rounded-xl p-5">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2">
                <Calculator className="w-5 h-5 text-blue-400" />
                <h3 className="text-sm font-bold text-white">
                  Second-Life Valuation & Repurposing Calculator (API Computed)
                </h3>
              </div>
              <span className="text-[11px] font-mono text-blue-300 bg-blue-500/10 px-2.5 py-0.5 rounded border border-blue-500/30">
                POST /api/batteries/{battery.id}/evaluate-second-life
              </span>
            </div>

            {evalLoading || !evaluation ? (
              <div className="text-xs text-slate-400 py-4">
                Calculating usable energy capacity and market resale valuation...
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
                  <div className="text-xs text-slate-400">Usable Second-Life Capacity</div>
                  <div className="text-xl font-bold text-white mt-1">
                    {evaluation.usable_capacity_kwh.toLocaleString()} kWh
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {battery.nominal_capacity_kwh} kWh × {battery.state_of_health_pct}% SoH
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
                  <div className="text-xs text-slate-400">Estimated Resale Valuation</div>
                  <div className="text-xl font-bold text-emerald-400 mt-1">
                    €{evaluation.estimated_resale_value_eur.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Tier Rate: €{evaluation.tier_rate_eur_per_kwh}/kWh (
                    {battery.state_of_health_pct > 80 ? 'SoH > 80%' : 'SoH ≤ 80%'})
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
                  <div className="text-xs text-slate-400">Recommended Second-Life Pathway</div>
                  <div className="text-xs font-bold text-blue-300 mt-1.5 leading-snug flex items-start gap-1.5">
                    <Zap className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>{evaluation.recommended_application}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Role-Specific Action Footer */}
        <div className="bg-slate-950 border-t border-slate-800 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs text-slate-400">
            Active Operator Role:{' '}
            <span className="font-mono font-semibold text-white">{user.role}</span> ({user.email})
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {user.role === 'OEM_ADMIN' && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  if (onOpenAddModal) onOpenAddModal();
                }}
                className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-2 shadow-lg shadow-blue-600/25 transition cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                Register Another OEM Pack
              </button>
            )}

            {user.role === 'EU_AUDITOR' && (
              <button
                type="button"
                disabled={actionLoading}
                onClick={handleAuditToggle}
                className={`px-4 py-2 rounded-lg text-white text-xs font-semibold flex items-center gap-2 transition cursor-pointer ${
                  battery.compliance_status === 'VERIFIED'
                    ? 'bg-rose-600 hover:bg-rose-500 shadow-lg shadow-rose-600/20'
                    : 'bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/20'
                }`}
              >
                {battery.compliance_status === 'VERIFIED' ? (
                  <>
                    <ShieldAlert className="w-4 h-4" />
                    {actionLoading ? 'Updating...' : 'Flag Non-Compliant (Art. 77 Audit)'}
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    {actionLoading ? 'Updating...' : 'Approve & Verify EU Compliance'}
                  </>
                )}
              </button>
            )}

            {user.role === 'SECOND_LIFE_BUYER' && (
              <button
                type="button"
                disabled={actionLoading || battery.market_status === 'REPURPOSED_GRID_STORAGE'}
                onClick={handlePurchase}
                className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 text-xs font-bold flex items-center gap-2 shadow-lg shadow-amber-500/20 transition cursor-pointer"
              >
                <ShoppingCart className="w-4 h-4" />
                {battery.market_status === 'REPURPOSED_GRID_STORAGE'
                  ? `Already Repurposed (${battery.second_life_passport_id || 'Issued'})`
                  : actionLoading
                  ? 'Issuing Linked Passport...'
                  : 'Purchase & Issue Second-Life Passport (Art. 77(7))'}
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition cursor-pointer"
            >
              Close Passport
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
