const API_BASE = import.meta.env.VITE_API_URL || '';

export function getStoredAuth() {
  try {
    const raw = localStorage.getItem('voltpass_auth');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setStoredAuth(authData) {
  if (!authData) {
    localStorage.removeItem('voltpass_auth');
  } else {
    localStorage.setItem('voltpass_auth', JSON.stringify(authData));
  }
}

async function request(path, options = {}) {
  const auth = getStoredAuth();
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (auth?.access_token) {
    headers['Authorization'] = `Bearer ${auth.access_token}`;
  }

  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers,
    });
  } catch {
    res = await fetch(`http://127.0.0.1:8000${path}`, {
      ...options,
      headers,
    });
  }

  if (!res.ok) {
    let errDetail = `HTTP Error ${res.status}`;
    try {
      const data = await res.json();
      if (data?.detail) {
        errDetail = typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail);
      }
    } catch {
      // ignore json parse failure
    }
    throw new Error(errDetail);
  }

  return res.json();
}

export const api = {
  login: (email, password) =>
    request('/api/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  getFaceProfiles: () => request('/api/face-profiles'),

  enrollFaceProfile: (email, descriptor, extra = {}) =>
    request('/api/face-enroll', {
      method: 'POST',
      body: JSON.stringify({
        email,
        descriptor,
        enrollment_source: 'FRONTEND_PORTAL',
        ...extra,
      }),
    }),

  clearFaceProfile: (email) =>
    request(`/api/face-enroll/${encodeURIComponent(email)}`, {
      method: 'DELETE',
    }),

  faceLogin: (descriptor, target_email = null) =>
    request('/api/face-login', {
      method: 'POST',
      body: JSON.stringify({ descriptor, target_email }),
    }),

  getBatteries: () => request('/api/batteries'),

  createBattery: (batteryData) =>
    request('/api/batteries', {
      method: 'POST',
      body: JSON.stringify(batteryData),
    }),

  auditBattery: (id, payload = {}) =>
    request(`/api/batteries/${id}/audit`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  evaluateSecondLife: (id) =>
    request(`/api/batteries/${id}/evaluate-second-life`, {
      method: 'POST',
    }),

  purchaseBattery: (id) =>
    request(`/api/batteries/${id}/purchase`, {
      method: 'PATCH',
    }),
};
