from typing import List, Optional
from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    email: str
    password: str


class FaceEnrollRequest(BaseModel):
    email: str
    descriptor: List[float] = Field(..., min_length=16)
    enrollment_source: str = Field(default="FRONTEND_PORTAL")  # FRONTEND_PORTAL | BACKEND_ADMIN_CONSOLE
    customer_name: Optional[str] = None
    customer_organization: Optional[str] = None
    customer_email: Optional[str] = None


class BuyerRegisterRequest(BaseModel):
    name: str = Field(..., min_length=2)
    email: str = Field(..., min_length=4)
    organization: str = Field(default="Independent BESS Customer")
    password: Optional[str] = Field(default="Grid-Buy-88!")
    descriptor: List[float] = Field(..., min_length=16)


class FaceLoginRequest(BaseModel):
    descriptor: List[float] = Field(..., min_length=16)
    target_email: Optional[str] = None


class UserOut(BaseModel):
    id: int
    email: str
    name: str
    organization: str
    role: str
    has_face_enrolled: bool = False
    face_enrolled_at: Optional[str] = None
    enrolled_faces_count: int = 0

    class Config:
        from_attributes = True


class FaceMatchLoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut
    similarity_score: float
    match_mode: str = "BIOMETRIC_FACIAL_SCAN"


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class BatteryCreate(BaseModel):
    passport_id: Optional[str] = None
    model_name: str = Field(..., min_length=2)
    manufacturer: str = Field(default="Volkswagen Group / PowerCo SE")
    manufacturing_date: str = Field(default="2026-09-15")
    chemistry: str = Field(..., description="NMC-811, LFP, or NCA")
    nominal_capacity_kwh: float = Field(..., gt=0)
    state_of_health_pct: float = Field(..., ge=0, le=100)
    charge_cycles: int = Field(..., ge=0)
    internal_resistance_mohm: float = Field(..., gt=0)
    carbon_footprint_kg_per_kwh: float = Field(..., gt=0)
    cobalt_origin: str = Field(...)
    recycled_cobalt_pct: float = Field(default=16.5, ge=0, le=100)
    recycled_lithium_pct: float = Field(..., ge=0, le=100)
    recycled_nickel_pct: float = Field(default=9.0, ge=0, le=100)
    audit_notes: str = Field(default="OEM conformity self-declaration submitted under Art. 77.")
    compliance_status: str = Field(default="PENDING_AUDIT")
    market_status: str = Field(default="AVAILABLE_FOR_SECOND_LIFE")


class AuditUpdateRequest(BaseModel):
    compliance_status: Optional[str] = None
    audit_notes: Optional[str] = None


class BatteryOut(BaseModel):
    id: int
    passport_id: str
    model_name: str
    manufacturer: str
    manufacturing_date: str
    chemistry: str
    nominal_capacity_kwh: float
    state_of_health_pct: float
    charge_cycles: int
    internal_resistance_mohm: float
    carbon_footprint_kg_per_kwh: float
    cobalt_origin: str
    recycled_cobalt_pct: float
    recycled_lithium_pct: float
    recycled_nickel_pct: float
    audit_notes: str
    compliance_status: str
    market_status: str
    second_life_passport_id: Optional[str] = None

    class Config:
        from_attributes = True


class SecondLifeEvaluationOut(BaseModel):
    battery_id: int
    passport_id: str
    model_name: str
    nominal_capacity_kwh: float
    state_of_health_pct: float
    usable_capacity_kwh: float
    tier_rate_eur_per_kwh: float
    estimated_resale_value_eur: float
    recommended_application: str
    regulation_reference: str = "EU Regulation 2023/1542 Art. 77 & Annex XIII"
