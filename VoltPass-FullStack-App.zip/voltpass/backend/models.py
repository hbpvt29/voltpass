from sqlalchemy import Column, Integer, String, Float
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    organization = Column(String, nullable=False)
    role = Column(String, nullable=False)  # OEM_ADMIN | EU_AUDITOR | SECOND_LIFE_BUYER
    password_hash = Column(String, nullable=False)
    face_descriptor = Column(String, nullable=True)  # JSON array of float biometric signature
    face_enrolled_at = Column(String, nullable=True)


class Battery(Base):
    __tablename__ = "batteries"

    id = Column(Integer, primary_key=True, index=True)
    passport_id = Column(String, unique=True, index=True, nullable=False)
    model_name = Column(String, nullable=False)
    manufacturer = Column(String, nullable=False)
    manufacturing_date = Column(String, nullable=False)
    chemistry = Column(String, nullable=False)  # NMC-811 | LFP | NCA
    nominal_capacity_kwh = Column(Float, nullable=False)
    state_of_health_pct = Column(Float, nullable=False)
    charge_cycles = Column(Integer, nullable=False)
    internal_resistance_mohm = Column(Float, nullable=False)
    carbon_footprint_kg_per_kwh = Column(Float, nullable=False)
    cobalt_origin = Column(String, nullable=False)  # Confidential (Art. 77 Annex XIII)
    recycled_cobalt_pct = Column(Float, nullable=False, default=12.0)
    recycled_lithium_pct = Column(Float, nullable=False)
    recycled_nickel_pct = Column(Float, nullable=False, default=8.0)
    audit_notes = Column(String, nullable=False, default="Initial EU conformity declaration logged.")
    compliance_status = Column(String, nullable=False)  # VERIFIED | PENDING_AUDIT | FLAGGED_NON_COMPLIANT
    market_status = Column(String, nullable=False)  # IN_VEHICLE | AVAILABLE_FOR_SECOND_LIFE | REPURPOSED_GRID_STORAGE
    second_life_passport_id = Column(String, nullable=True)
