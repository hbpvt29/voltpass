from sqlalchemy.orm import Session
from models import User, Battery
from auth import hash_password


def seed_database(db: Session):
    # 1. Seed the 3 strict Enterprise Users
    preseeded_users = [
        {
            "email": "oem@voltpass.eu",
            "password": "OEM-Pass-2027!",
            "name": "Dr. Lukas Weber",
            "organization": "Porsche AG / VW PowerCo OEM Engineering",
            "role": "OEM_ADMIN",
        },
        {
            "email": "auditor@tuv-eu.org",
            "password": "Audit-EU-77!",
            "name": "Ingrid Lindqvist",
            "organization": "TÜV Rheinland EU Notified Body #0197",
            "role": "EU_AUDITOR",
        },
        {
            "email": "buyer@gridstore.de",
            "password": "Grid-Buy-88!",
            "name": "Markus Vance",
            "organization": "GridStore DE Stationary BESS Procurement",
            "role": "SECOND_LIFE_BUYER",
        },
    ]

    for u in preseeded_users:
        existing = db.query(User).filter(User.email == u["email"]).first()
        if not existing:
            db.add(
                User(
                    email=u["email"],
                    name=u["name"],
                    organization=u["organization"],
                    role=u["role"],
                    password_hash=hash_password(u["password"]),
                )
            )
        else:
            existing.password_hash = hash_password(u["password"])
            existing.role = u["role"]
            existing.name = u["name"]
            existing.organization = u["organization"]

    # 2. Seed 8 realistic EV & Industrial Battery Packs
    preseeded_batteries = [
        {
            "passport_id": "EU-DBP-2027-de89a1",
            "model_name": "800V Taycan J1 Performance Pack",
            "manufacturer": "Dr. Ing. h.c. F. Porsche AG (Zuffenhausen)",
            "manufacturing_date": "2024-03-18",
            "chemistry": "NMC-811",
            "nominal_capacity_kwh": 93.4,
            "state_of_health_pct": 86.5,
            "charge_cycles": 780,
            "internal_resistance_mohm": 42.5,
            "carbon_footprint_kg_per_kwh": 64.2,
            "cobalt_origin": "DRC - Certified (RMAP Audited Kamoto Mine)",
            "recycled_cobalt_pct": 18.4,
            "recycled_lithium_pct": 12.0,
            "recycled_nickel_pct": 11.2,
            "audit_notes": "TÜV Conformity Assessment passed. RMAP chain-of-custody certificates verified under Art. 48.",
            "compliance_status": "VERIFIED",
            "market_status": "AVAILABLE_FOR_SECOND_LIFE",
            "second_life_passport_id": None,
        },
        {
            "passport_id": "EU-DBP-2027-st44b2",
            "model_name": "eActros Heavy Duty LFP Module",
            "manufacturer": "Mercedes-Benz Energy GmbH (Kamenz)",
            "manufacturing_date": "2023-11-04",
            "chemistry": "LFP",
            "nominal_capacity_kwh": 112.0,
            "state_of_health_pct": 78.2,
            "charge_cycles": 1640,
            "internal_resistance_mohm": 55.8,
            "carbon_footprint_kg_per_kwh": 58.9,
            "cobalt_origin": "Cobalt-Free Cathode (Morocco/Chile Verified Brine)",
            "recycled_cobalt_pct": 0.0,
            "recycled_lithium_pct": 8.5,
            "recycled_nickel_pct": 0.0,
            "audit_notes": "LFP heavy-duty commercial module verified. Zero cobalt declaration confirmed via XRF assay.",
            "compliance_status": "VERIFIED",
            "market_status": "AVAILABLE_FOR_SECOND_LIFE",
            "second_life_passport_id": None,
        },
        {
            "passport_id": "EU-DBP-2027-by91c3",
            "model_name": "BMW Gen6 Cylindrical Pack",
            "manufacturer": "BMW Group Plant Dingolfing",
            "manufacturing_date": "2025-07-22",
            "chemistry": "NMC-811",
            "nominal_capacity_kwh": 94.0,
            "state_of_health_pct": 94.0,
            "charge_cycles": 350,
            "internal_resistance_mohm": 36.1,
            "carbon_footprint_kg_per_kwh": 52.4,
            "cobalt_origin": "Morocco - Bou Azzer Certified Responsible Mining",
            "recycled_cobalt_pct": 22.0,
            "recycled_lithium_pct": 18.0,
            "recycled_nickel_pct": 15.5,
            "audit_notes": "Exceeds all 2031 Article 8 recycled content thresholds. Active first-life vehicle telemetry normal.",
            "compliance_status": "VERIFIED",
            "market_status": "IN_VEHICLE",
            "second_life_passport_id": None,
        },
        {
            "passport_id": "EU-DBP-2027-vw77d4",
            "model_name": "MEB ID.Buzz Fleet Cargo Pack",
            "manufacturer": "Volkswagen Group Components (Salzgitter)",
            "manufacturing_date": "2023-08-11",
            "chemistry": "NMC-811",
            "nominal_capacity_kwh": 82.0,
            "state_of_health_pct": 74.5,
            "charge_cycles": 1490,
            "internal_resistance_mohm": 61.4,
            "carbon_footprint_kg_per_kwh": 71.0,
            "cobalt_origin": "Finland - Terrafame Sotkamo Hydrometallurgical",
            "recycled_cobalt_pct": 16.2,
            "recycled_lithium_pct": 6.5,
            "recycled_nickel_pct": 7.8,
            "audit_notes": "European domestic precursor origin verified. Decommissioned from municipal postal fleet.",
            "compliance_status": "VERIFIED",
            "market_status": "AVAILABLE_FOR_SECOND_LIFE",
            "second_life_passport_id": None,
        },
        {
            "passport_id": "EU-DBP-2027-ts19e5",
            "model_name": "Berlin Structural 4680 Array",
            "manufacturer": "Gigafactory Berlin-Brandenburg",
            "manufacturing_date": "2023-02-27",
            "chemistry": "NCA",
            "nominal_capacity_kwh": 75.0,
            "state_of_health_pct": 68.0,
            "charge_cycles": 2400,
            "internal_resistance_mohm": 79.6,
            "carbon_footprint_kg_per_kwh": 88.5,
            "cobalt_origin": "DRC - Unverified Artisanal Lot #44 (Missing Smelter Cert)",
            "recycled_cobalt_pct": 9.5,
            "recycled_lithium_pct": 4.0,
            "recycled_nickel_pct": 4.2,
            "audit_notes": "NON-COMPLIANT FLAG: Upstream smelter audit certificate missing under Art. 52 Supply Chain Due Diligence.",
            "compliance_status": "FLAGGED_NON_COMPLIANT",
            "market_status": "AVAILABLE_FOR_SECOND_LIFE",
            "second_life_passport_id": None,
        },
        {
            "passport_id": "EU-DBP-2027-rn63f6",
            "model_name": "Scenic E-Tech High-Density Pack",
            "manufacturer": "Ampere ElectriCity / AESC Douai",
            "manufacturing_date": "2024-06-14",
            "chemistry": "NMC-811",
            "nominal_capacity_kwh": 87.0,
            "state_of_health_pct": 83.0,
            "charge_cycles": 890,
            "internal_resistance_mohm": 46.0,
            "carbon_footprint_kg_per_kwh": 61.8,
            "cobalt_origin": "Recycled Secondary (Umicore Hoboken EU Closed-Loop)",
            "recycled_cobalt_pct": 24.5,
            "recycled_lithium_pct": 14.5,
            "recycled_nickel_pct": 12.8,
            "audit_notes": "Awaiting final Notified Body sign-off on Umicore batch mass-balance certificate.",
            "compliance_status": "PENDING_AUDIT",
            "market_status": "AVAILABLE_FOR_SECOND_LIFE",
            "second_life_passport_id": None,
        },
        {
            "passport_id": "EU-DBP-2027-vo28g7",
            "model_name": "Volvo FH Electric Traction Block",
            "manufacturer": "Volvo Energy AB (Gothenburg)",
            "manufacturing_date": "2023-05-09",
            "chemistry": "NCA",
            "nominal_capacity_kwh": 90.0,
            "state_of_health_pct": 81.5,
            "charge_cycles": 1120,
            "internal_resistance_mohm": 49.3,
            "carbon_footprint_kg_per_kwh": 67.4,
            "cobalt_origin": "Australia - Murrin Murrin ISO-14001 Certified",
            "recycled_cobalt_pct": 17.0,
            "recycled_lithium_pct": 10.2,
            "recycled_nickel_pct": 9.4,
            "audit_notes": "Transferred to stationary grid operator under Art. 77(7) linked passport.",
            "compliance_status": "VERIFIED",
            "market_status": "REPURPOSED_GRID_STORAGE",
            "second_life_passport_id": "EU-DBP-SL-2027-9941a0",
        },
        {
            "passport_id": "EU-DBP-2027-nv50h8",
            "model_name": "Northvolt Ett Industrial BESS Cube",
            "manufacturer": "Northvolt AB (Skellefteå, Sweden)",
            "manufacturing_date": "2025-01-30",
            "chemistry": "LFP",
            "nominal_capacity_kwh": 105.0,
            "state_of_health_pct": 91.2,
            "charge_cycles": 520,
            "internal_resistance_mohm": 38.9,
            "carbon_footprint_kg_per_kwh": 46.1,
            "cobalt_origin": "Recycled Secondary (Hydrovolt Nordic Black Mass)",
            "recycled_cobalt_pct": 19.0,
            "recycled_lithium_pct": 16.0,
            "recycled_nickel_pct": 14.0,
            "audit_notes": "100% Nordic hydro-powered cell manufacturing. Pending annual carbon footprint verification.",
            "compliance_status": "PENDING_AUDIT",
            "market_status": "IN_VEHICLE",
            "second_life_passport_id": None,
        },
    ]

    existing_count = db.query(Battery).count()
    if existing_count == 0:
        for b in preseeded_batteries:
            db.add(Battery(**b))

    db.commit()
