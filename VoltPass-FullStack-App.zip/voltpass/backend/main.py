import json
import math
import secrets
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import List

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from sqlalchemy import text
from sqlalchemy.orm import Session

from auth import (
    create_access_token,
    get_current_user,
    require_roles,
    verify_password,
)
from database import Base, SessionLocal, engine, get_db
from models import Battery, User
from schemas import (
    AuditUpdateRequest,
    BatteryCreate,
    BatteryOut,
    FaceEnrollRequest,
    FaceLoginRequest,
    FaceMatchLoginResponse,
    LoginRequest,
    LoginResponse,
    SecondLifeEvaluationOut,
    UserOut,
)
from seed import seed_database

RESTRICTED_TEXT = "RESTRICTED (Art. 77 Annex XIII)"


def ensure_biometric_columns():
    with engine.connect() as conn:
        cols = [row[1] for row in conn.execute(text("PRAGMA table_info(users)")).fetchall()]
        if "face_descriptor" not in cols:
            conn.execute(text("ALTER TABLE users ADD COLUMN face_descriptor TEXT"))
        if "face_enrolled_at" not in cols:
            conn.execute(text("ALTER TABLE users ADD COLUMN face_enrolled_at TEXT"))
        conn.commit()


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    ensure_biometric_columns()
    db = SessionLocal()
    try:
        seed_database(db)
    finally:
        db.close()
    yield


app = FastAPI(
    title="VoltPass: EU Digital Battery Passport & Second-Life Marketplace API",
    description="Implements EU Regulation 2023/1542 (Article 77 & Annex XIII) with RBAC field masking and Second-Life valuation.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def parse_enrolled_faces(user: User) -> List[dict]:
    """
    Returns a list of enrolled face entries for a user.
    - For OEM_ADMIN & EU_AUDITOR: at most 1 entry [{"name": ..., "email": ..., "descriptor": [...], "enrolled_at": ...}]
    - For SECOND_LIFE_BUYER: N customer entries [{"name": ..., "email": ..., "organization": ..., "descriptor": [...], "enrolled_at": ...}]
    """
    if not user.face_descriptor:
        return []
    try:
        raw = json.loads(user.face_descriptor)
        if not raw:
            return []
        # Legacy single-array format: [0.12, 0.34, ...]
        if isinstance(raw, list) and isinstance(raw[0], (int, float)):
            return [
                {
                    "name": user.name,
                    "email": user.email,
                    "organization": user.organization,
                    "descriptor": raw,
                    "enrolled_at": user.face_enrolled_at or "Enrolled",
                }
            ]
        # Multi-entry list of dicts format
        if isinstance(raw, list) and isinstance(raw[0], dict):
            return raw
    except Exception:
        pass
    return []


def serialize_user(user: User, active_customer: dict = None) -> UserOut:
    entries = parse_enrolled_faces(user)
    return UserOut(
        id=user.id,
        email=active_customer.get("email", user.email) if active_customer else user.email,
        name=active_customer.get("name", user.name) if active_customer else user.name,
        organization=active_customer.get("organization", user.organization) if active_customer else user.organization,
        role=user.role,
        has_face_enrolled=len(entries) > 0,
        face_enrolled_at=user.face_enrolled_at,
        enrolled_faces_count=len(entries),
    )


def normalized_biometric_similarity(vec_a: List[float], vec_b: List[float]) -> float:
    if not vec_a or not vec_b or len(vec_a) != len(vec_b):
        return 0.0
    n = len(vec_a)
    mean_a = sum(vec_a) / n
    mean_b = sum(vec_b) / n
    ca = [a - mean_a for a in vec_a]
    cb = [b - mean_b for b in vec_b]
    dot = sum(a * b for a, b in zip(ca, cb))
    norm_a = math.sqrt(sum(a * a for a in ca))
    norm_b = math.sqrt(sum(b * b for b in cb))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    corr = dot / (norm_a * norm_b)  # -1.0 to +1.0
    # Also compute L1 closeness
    l1_dist = sum(abs(a - b) for a, b in zip(vec_a, vec_b)) / n
    l1_sim = max(0.0, 1.0 - l1_dist * 3.2)
    return max(0.0, (corr * 0.65) + (l1_sim * 0.35))


def serialize_battery_for_role(battery: Battery, role: str) -> BatteryOut:
    data = BatteryOut.model_validate(battery)
    if role == "SECOND_LIFE_BUYER":
        data.cobalt_origin = RESTRICTED_TEXT
        data.audit_notes = RESTRICTED_TEXT
    return data


@app.get("/", response_class=HTMLResponse)
def root_status(db: Session = Depends(get_db)):
    users = db.query(User).order_by(User.id.asc()).all()
    batteries = db.query(Battery).order_by(Battery.id.asc()).all()

    user_rows = "".join(
        f"""
        <tr style="border-bottom:1px solid #1e293b;">
            <td style="padding:10px 14px;font-family:monospace;color:#60a5fa;">{u.email}</td>
            <td style="padding:10px 14px;font-weight:600;color:#f8fafc;">{u.name}</td>
            <td style="padding:10px 14px;color:#94a3b8;">{u.organization}</td>
            <td style="padding:10px 14px;"><span style="background:#1e3a8a;color:#93c5fd;padding:3px 8px;border-radius:6px;font-size:11px;font-family:monospace;">{u.role}</span></td>
            <td style="padding:10px 14px;">
                {'<span style="background:#312e81;color:#c7d2fe;padding:3px 8px;border-radius:6px;font-size:11px;font-family:monospace;">1 UNIQUE OPERATOR (BACKEND :8000)</span>' if u.role in ('OEM_ADMIN', 'EU_AUDITOR') else '<span style="background:#78350f;color:#fde68a;padding:3px 8px;border-radius:6px;font-size:11px;font-family:monospace;">N CUSTOMERS SELF-ENROLL (FRONTEND :5173)</span>'}
            </td>
            <td style="padding:10px 14px;">
                {('<span style="background:#064e3b;color:#6ee7b7;padding:3px 8px;border-radius:6px;font-size:11px;font-family:monospace;">✓ ' + str(len(parse_enrolled_faces(u))) + (' BUYER(S) ENROLLED' if u.role == 'SECOND_LIFE_BUYER' else ' UNIQUE FACE ENROLLED') + '</span>') if len(parse_enrolled_faces(u)) > 0 else '<span style="color:#64748b;font-size:11px;font-family:monospace;">0 ENROLLED</span>'}
            </td>
            <td style="padding:10px 14px;text-align:right;">
                {f'<button onclick="clearFace(\'{u.email}\')" style="background:#7f1d1d;color:#fecaca;border:1px solid #ef4444;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;">Reset Face(s)</button>' if len(parse_enrolled_faces(u)) > 0 else ''}
            </td>
        </tr>
        """
        for u in users
    )

    battery_rows = "".join(
        f"""
        <tr style="border-bottom:1px solid #1e293b;">
            <td style="padding:8px 14px;font-family:monospace;color:#38bdf8;">{b.passport_id}</td>
            <td style="padding:8px 14px;color:#f8fafc;font-weight:600;">{b.model_name}</td>
            <td style="padding:8px 14px;font-family:monospace;color:#cbd5e1;">{b.chemistry}</td>
            <td style="padding:8px 14px;font-family:monospace;color:#cbd5e1;">{b.nominal_capacity_kwh} kWh</td>
            <td style="padding:8px 14px;font-family:monospace;color:#34d399;font-weight:700;">{b.state_of_health_pct}%</td>
            <td style="padding:8px 14px;font-size:12px;color:#fde68a;">{b.cobalt_origin}</td>
            <td style="padding:8px 14px;font-family:monospace;font-size:11px;color:#e2e8f0;">{b.compliance_status}</td>
            <td style="padding:8px 14px;font-family:monospace;font-size:11px;color:#93c5fd;">{b.market_status}</td>
        </tr>
        """
        for b in batteries
    )

    html_content = f"""<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>VoltPass Sovereign Backend Authority & Biometric Provisioning Console (:8000)</title>
    </head>
    <body style="margin:0;background:#020617;color:#f8fafc;font-family:system-ui,-apple-system,sans-serif;padding:28px;">
        <div style="max-width:1160px;margin:0 auto;">
            <!-- Header -->
            <div style="display:flex;align-items:center;justify-content:space-between;background:#0f172a;border:1px solid #1e293b;padding:20px 24px;border-radius:14px;margin-bottom:24px;">
                <div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#10b981;box-shadow:0 0 10px #10b981;"></span>
                        <h1 style="margin:0;font-size:20px;">VoltPass Sovereign Backend Console & Biometric Enrollment Authority (Port 8000)</h1>
                    </div>
                    <p style="margin:6px 0 0 0;color:#94a3b8;font-size:13px;">
                        Privileged EU Operators (<code>OEM_ADMIN</code> & <code>EU_AUDITOR</code>) MUST enroll their facial biometrics here in the Backend Console, then log in on the Frontend (<code>:5173</code>). Second-Life Buyers self-enroll on the Frontend.
                    </p>
                </div>
                <div style="display:flex;gap:10px;">
                    <a href="http://localhost:5173" style="background:#10b981;color:#022c22;text-decoration:none;padding:10px 16px;border-radius:8px;font-size:13px;font-weight:700;">Go to Frontend Login (:5173) →</a>
                    <a href="/docs" style="background:#1e293b;color:#e2e8f0;border:1px solid #334155;text-decoration:none;padding:10px 16px;border-radius:8px;font-size:13px;font-weight:600;">Swagger API (/docs)</a>
                </div>
            </div>

            <!-- Privileged Backend Biometric Enrollment Studio (OEM_ADMIN & EU_AUDITOR) -->
            <div style="display:grid;grid-template-columns:360px 1fr;gap:24px;background:linear-gradient(135deg,#0f172a 0%,#09152b 100%);border:1px solid #1d4ed8;border-radius:14px;padding:22px;margin-bottom:24px;">
                <div>
                    <div style="position:relative;width:100%;height:230px;background:#020617;border:2px solid #10b981;border-radius:12px;overflow:hidden;display:flex;align-items:center;justify-content:center;">
                        <video id="backendCam" autoplay playsinline muted style="width:100%;height:100%;object-fit:cover;transform:scaleX(-1);"></video>
                        <div id="camFallback" style="display:none;text-align:center;padding:16px;color:#38bdf8;font-family:monospace;font-size:12px;">
                            [OPTICAL SENSOR READY]<br/><span style="color:#94a3b8;font-size:11px;">Single-Operator Biometric Vector Generator Active</span>
                        </div>
                        <div style="position:absolute;inset:24px;border:2px dashed rgba(16,185,129,0.7);border-radius:20px;pointer-events:none;"></div>
                        <div style="position:absolute;bottom:8px;left:8px;right:8px;background:rgba(2,6,23,0.85);padding:5px 10px;border-radius:6px;font-family:monospace;font-size:11px;color:#6ee7b7;" id="scanStatus">
                            SENSOR READY FOR PRIVILEGED ENROLLMENT
                        </div>
                    </div>
                </div>

                <div style="display:flex;flex-direction:column;justify-content:space-between;">
                    <div>
                        <span style="background:#1e3a8a;color:#93c5fd;padding:4px 10px;border-radius:999px;font-size:11px;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;">
                            Backend Biometric Provisioning Authority (Art. 77 Security Gate)
                        </span>
                        <h2 style="margin:10px 0 6px 0;font-size:18px;color:#ffffff;">
                            Enroll Privileged Operator Face (OEM Engineer / EU Compliance Auditor)
                        </h2>
                        <p style="margin:0 0 16px 0;color:#cbd5e1;font-size:13px;line-height:1.5;">
                            Select your privileged operator profile below and click <strong>Capture & Enroll Face in Backend DB</strong>. Once enrolled here in the backend, go to the Frontend (<code>http://localhost:5173</code>) and scan your face—it will exclusively unlock your enrolled profile and block all other roles.
                        </p>

                        <div style="margin-bottom:14px;">
                            <label style="display:block;font-size:12px;color:#94a3b8;margin-bottom:6px;font-weight:600;">
                                Select Privileged EU Operator Profile to Bind Your Face:
                            </label>
                            <select id="operatorSelect" style="width:100%;padding:11px 14px;background:#020617;border:1px solid #3b82f6;color:#ffffff;border-radius:8px;font-size:13px;font-weight:600;">
                                <option value="auditor@tuv-eu.org">EU Compliance Auditor — Ingrid Lindqvist (auditor@tuv-eu.org | EU_AUDITOR)</option>
                                <option value="oem@voltpass.eu">OEM Engineer — Dr. Lukas Weber (oem@voltpass.eu | OEM_ADMIN)</option>
                            </select>
                        </div>

                        <div id="enrollResultBanner" style="display:none;padding:12px 14px;border-radius:8px;font-size:13px;font-weight:600;margin-bottom:12px;"></div>
                    </div>

                    <div style="display:flex;align-items:center;gap:12px;">
                        <button onclick="enrollFromBackend()" style="background:#10b981;color:#022c22;border:none;padding:12px 22px;border-radius:8px;font-size:13px;font-weight:800;cursor:pointer;box-shadow:0 4px 14px rgba(16,185,129,0.3);">
                            📷 Capture & Enroll Face in Backend DB
                        </button>
                        <a href="http://localhost:5173" style="background:#2563eb;color:white;text-decoration:none;padding:12px 18px;border-radius:8px;font-size:13px;font-weight:600;">
                            Test Facial Login on Frontend (:5173) →
                        </a>
                    </div>
                </div>
            </div>

            <!-- Operator Registry Table -->
            <div style="background:#0f172a;border:1px solid #1e293b;border-radius:14px;padding:20px;margin-bottom:24px;">
                <h2 style="margin:0 0 12px 0;font-size:15px;color:#93c5fd;">1. Pre-Seeded EU Economic Operators & Biometric Enrollment Policy</h2>
                <table style="width:100%;border-collapse:collapse;font-size:13px;text-align:left;">
                    <thead>
                        <tr style="border-bottom:1px solid #334155;color:#94a3b8;font-size:11px;text-transform:uppercase;">
                            <th style="padding:10px 14px;">Email</th>
                            <th style="padding:10px 14px;">Operator Name</th>
                            <th style="padding:10px 14px;">Organization</th>
                            <th style="padding:10px 14px;">Role</th>
                            <th style="padding:10px 14px;">Allowed Enrollment Portal</th>
                            <th style="padding:10px 14px;">Biometric Status</th>
                            <th style="padding:10px 14px;text-align:right;">Action</th>
                        </tr>
                    </thead>
                    <tbody>{user_rows}</tbody>
                </table>
            </div>

            <!-- Battery Registry Table -->
            <div style="background:#0f172a;border:1px solid #1e293b;border-radius:14px;padding:20px;">
                <h2 style="margin:0 0 12px 0;font-size:15px;color:#34d399;">2. Live SQLite Database Records (voltpass.db — {len(batteries)} Battery Passports)</h2>
                <table style="width:100%;border-collapse:collapse;font-size:13px;text-align:left;">
                    <thead>
                        <tr style="border-bottom:1px solid #334155;color:#94a3b8;font-size:11px;text-transform:uppercase;">
                            <th style="padding:8px 14px;">Passport ID</th>
                            <th style="padding:8px 14px;">Model Name</th>
                            <th style="padding:8px 14px;">Chem</th>
                            <th style="padding:8px 14px;">Capacity</th>
                            <th style="padding:8px 14px;">SoH</th>
                            <th style="padding:8px 14px;">Cobalt Origin (DB Raw)</th>
                            <th style="padding:8px 14px;">Audit Status</th>
                            <th style="padding:8px 14px;">Market Status</th>
                        </tr>
                    </thead>
                    <tbody>{battery_rows}</tbody>
                </table>
            </div>
        </div>

        <script>
            let camActive = false;
            const videoEl = document.getElementById('backendCam');
            const fallbackEl = document.getElementById('camFallback');
            const statusEl = document.getElementById('scanStatus');
            const bannerEl = document.getElementById('enrollResultBanner');

            async function initBackendCam() {{
                try {{
                    const stream = await navigator.mediaDevices.getUserMedia({{ video: {{ width: 640, height: 480, facingMode: 'user' }}, audio: false }});
                    videoEl.srcObject = stream;
                    camActive = true;
                    statusEl.textContent = 'LIVE WEBCAM FEED ACTIVE (64-D EMBEDDING)';
                }} catch (e) {{
                    camActive = false;
                    videoEl.style.display = 'none';
                    fallbackEl.style.display = 'block';
                    statusEl.textContent = 'SYNTHETIC BIOMETRIC SENSOR ACTIVE';
                }}
            }}
            initBackendCam();

            function extractDescriptor() {{
                if (camActive && videoEl.readyState >= 2) {{
                    const canvas = document.createElement('canvas');
                    const size = 64;
                    canvas.width = size;
                    canvas.height = size;
                    const ctx = canvas.getContext('2d');
                    const vw = videoEl.videoWidth || 320;
                    const vh = videoEl.videoHeight || 240;
                    const cropSize = Math.min(vw, vh) * 0.65;
                    const sx = (vw - cropSize) / 2;
                    const sy = (vh - cropSize) / 2;
                    ctx.drawImage(videoEl, sx, sy, cropSize, cropSize, 0, 0, size, size);
                    const imgData = ctx.getImageData(0, 0, size, size).data;
                    const blockSize = 8;
                    const descriptor = [];
                    for (let br = 0; br < 8; br++) {{
                        for (let bc = 0; bc < 8; bc++) {{
                            let sumLum = 0;
                            let sumGrad = 0;
                            for (let r = 0; r < blockSize; r++) {{
                                for (let c = 0; c < blockSize; c++) {{
                                    const py = br * blockSize + r;
                                    const px = bc * blockSize + c;
                                    const idx = (py * size + px) * 4;
                                    const lum = 0.299 * imgData[idx] + 0.587 * imgData[idx + 1] + 0.114 * imgData[idx + 2];
                                    sumLum += lum;
                                    if (px + 1 < size) {{
                                        const idxR = (py * size + (px + 1)) * 4;
                                        const lumR = 0.299 * imgData[idxR] + 0.587 * imgData[idxR + 1] + 0.114 * imgData[idxR + 2];
                                        sumGrad += Math.abs(lum - lumR);
                                    }}
                                }}
                            }}
                            const meanLum = sumLum / (blockSize * blockSize * 255);
                            const meanGrad = sumGrad / (blockSize * blockSize * 255);
                            descriptor.push(Number((meanLum * 0.75 + meanGrad * 0.25 + 0.05).toFixed(5)));
                        }}
                    }}
                    return descriptor;
                }}
                // Fallback deterministic signature matching the frontend single-operator sensor
                const vec = [];
                const seed = 'physical-camera-operator-auditor-biometric-template';
                for (let i = 0; i < 64; i++) {{
                    const ch = seed.charCodeAt(i % seed.length);
                    const val = ((Math.sin(ch * (i + 1) * 0.41) + 1.15) * 0.42).toFixed(5);
                    vec.push(Number(val));
                }}
                return vec;
            }}

            async function enrollFromBackend() {{
                const email = document.getElementById('operatorSelect').value;
                statusEl.textContent = 'CAPTURING 64-D FACIAL EMBEDDING...';
                const descriptor = extractDescriptor();
                const res = await fetch('/api/face-enroll', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ email, descriptor, enrollment_source: 'BACKEND_ADMIN_CONSOLE' }})
                }});
                const data = await res.json();
                bannerEl.style.display = 'block';
                if (res.ok) {{
                    bannerEl.style.background = '#064e3b';
                    bannerEl.style.border = '1px solid #10b981';
                    bannerEl.style.color = '#a7f3d0';
                    bannerEl.innerHTML = '✓ Face successfully enrolled in Backend DB for <strong>' + data.name + ' (' + data.role + ')</strong>! Now open <a href="http://localhost:5173" style="color:#ffffff;text-decoration:underline;">http://localhost:5173</a> to log in via Facial Scan.';
                    statusEl.textContent = 'ENROLLED: ' + data.email;
                    setTimeout(() => window.location.reload(), 1400);
                }} else {{
                    bannerEl.style.background = '#7f1d1d';
                    bannerEl.style.border = '1px solid #ef4444';
                    bannerEl.style.color = '#fecaca';
                    bannerEl.textContent = data.detail || 'Enrollment failed.';
                }}
            }}

            async function clearFace(email) {{
                await fetch('/api/face-enroll/' + encodeURIComponent(email), {{ method: 'DELETE' }});
                window.location.reload();
            }}
        </script>
    </body>
    </html>
    """
    return HTMLResponse(
        content=html_content,
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
        },
    )


@app.get("/admin", response_class=HTMLResponse)
def admin_enrollment_console(db: Session = Depends(get_db)):
    return root_status(db)


@app.post("/api/login", response_model=LoginResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    email_clean = payload.email.strip().lower()
    user = db.query(User).filter(User.email == email_clean).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid EU Economic Operator credentials. Public registration is disabled.",
        )
    token = create_access_token(user)
    return LoginResponse(
        access_token=token,
        token_type="bearer",
        user=serialize_user(user),
    )


@app.get("/api/face-profiles", response_model=List[UserOut])
def list_face_profiles(db: Session = Depends(get_db)):
    users = db.query(User).order_by(User.id.asc()).all()
    return [serialize_user(u) for u in users]


@app.post("/api/face-enroll", response_model=UserOut)
def enroll_face_profile(payload: FaceEnrollRequest, db: Session = Depends(get_db)):
    email_clean = payload.email.strip().lower()
    user = db.query(User).filter(User.email == email_clean).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Operator profile not found.")

    # Policy enforcement:
    # - FRONTEND_PORTAL can ONLY enroll SECOND_LIFE_BUYER (buyer@gridstore.de).
    # - OEM_ADMIN and EU_AUDITOR MUST enroll via BACKEND_ADMIN_CONSOLE (http://localhost:8000/admin).
    if payload.enrollment_source != "BACKEND_ADMIN_CONSOLE" and user.role in ("OEM_ADMIN", "EU_AUDITOR"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                f"PRIVILEGED BIOMETRIC POLICY: {user.role} ({user.email}) is a unique single-person authority and cannot enroll on the Frontend. "
                f"OEM Engineers and EU Auditors must enroll their face in the Backend App (/admin)."
            ),
        )

    if payload.enrollment_source == "BACKEND_ADMIN_CONSOLE" and user.role == "SECOND_LIFE_BUYER":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Second-Life Buyers (Customers) self-register their faces on the Frontend portal (http://localhost:5173) to increase the registered buyer count.",
        )

    clean_vec = [round(float(x), 5) for x in payload.descriptor]
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    # Enforce Exclusive 1-Face-to-1-Role Policy across ALL profiles:
    # Remove any prior matching face from OTHER roles so one physical person can only belong to ONE role.
    all_users = db.query(User).all()
    for other in all_users:
        if other.id != user.id:
            other_entries = parse_enrolled_faces(other)
            filtered = [
                e for e in other_entries
                if normalized_biometric_similarity(clean_vec, e.get("descriptor", [])) < 0.72
            ]
            if len(filtered) != len(other_entries):
                other.face_descriptor = json.dumps(filtered) if filtered else None
                if not filtered:
                    other.face_enrolled_at = None

    if user.role in ("OEM_ADMIN", "EU_AUDITOR"):
        # STRICTLY 1 UNIQUE PERSON FOR OEM_ADMIN AND 1 UNIQUE PERSON FOR EU_AUDITOR
        single_entry = [
            {
                "name": user.name,
                "email": user.email,
                "organization": user.organization,
                "descriptor": clean_vec,
                "enrolled_at": now_str,
            }
        ]
        user.face_descriptor = json.dumps(single_entry)
        user.face_enrolled_at = now_str
    else:
        # SECOND_LIFE_BUYER: Single profile ('buyer@gridstore.de'), but N customers can enroll and increase the buyer count!
        existing_buyers = parse_enrolled_faces(user)
        cust_idx = len(existing_buyers) + 1
        cust_name = (payload.customer_name or "").strip() or f"Second-Life Customer #{cust_idx}"
        cust_org = (payload.customer_organization or "").strip() or "Registered BESS Marketplace Buyer"
        cust_email = (payload.customer_email or "").strip() or user.email

        existing_buyers.append(
            {
                "customer_id": cust_idx,
                "name": cust_name,
                "email": cust_email,
                "organization": cust_org,
                "descriptor": clean_vec,
                "enrolled_at": now_str,
            }
        )
        user.face_descriptor = json.dumps(existing_buyers)
        user.face_enrolled_at = now_str

    db.commit()
    db.refresh(user)
    return serialize_user(user)


@app.delete("/api/face-enroll/{email}", response_model=UserOut)
def clear_face_profile(email: str, db: Session = Depends(get_db)):
    email_clean = email.strip().lower()
    user = db.query(User).filter(User.email == email_clean).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Operator profile not found.")
    user.face_descriptor = None
    user.face_enrolled_at = None
    db.commit()
    db.refresh(user)
    return serialize_user(user)


@app.post("/api/face-login", response_model=FaceMatchLoginResponse)
def login_with_face_scan(payload: FaceLoginRequest, db: Session = Depends(get_db)):
    users = db.query(User).order_by(User.id.asc()).all()

    # Compare the live scanned face against all enrolled faces across the 3 profiles
    best_user = None
    best_entry = None
    best_score = -1.0

    for u in users:
        entries = parse_enrolled_faces(u)
        for entry in entries:
            sim = normalized_biometric_similarity(payload.descriptor, entry.get("descriptor", []))
            if sim > best_score:
                best_score = sim
                best_user = u
                best_entry = entry

    MATCH_THRESHOLD = 0.72

    # Case 1: Operator clicked a specific role card to log into (e.g., OEM_ADMIN, EU_AUDITOR, or SECOND_LIFE_BUYER)
    if payload.target_email:
        target_clean = payload.target_email.strip().lower()
        targeted_user = db.query(User).filter(User.email == target_clean).first()
        if not targeted_user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Target operator profile not found.")

        # If this face ALREADY belongs to a different role (e.g. enrolled as EU_AUDITOR, trying to open OEM_ADMIN or SECOND_LIFE_BUYER), strictly BLOCK!
        if best_user and best_score >= MATCH_THRESHOLD and best_user.id != targeted_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    f"BIOMETRIC ACCESS DENIED: Your face is registered exclusively to "
                    f"{best_entry.get('name', best_user.name)} ({best_user.role}). "
                    f"You cannot unlock {targeted_user.role} via Facial Scan."
                ),
            )

        target_entries = parse_enrolled_faces(targeted_user)
        if not target_entries:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=(
                    f"BIOMETRIC ACCESS DENIED: 0 faces are currently enrolled for {targeted_user.role} ({targeted_user.email})."
                ),
            )

        best_target_sim = -1.0
        best_target_entry = None
        for entry in target_entries:
            sim = normalized_biometric_similarity(payload.descriptor, entry.get("descriptor", []))
            if sim > best_target_sim:
                best_target_sim = sim
                best_target_entry = entry

        if best_target_sim < MATCH_THRESHOLD:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    f"BIOMETRIC MISMATCH ({round(best_target_sim * 100, 1)}% similarity): "
                    f"Scanned face does not match any enrolled face in {targeted_user.role}."
                ),
            )

        best_user = targeted_user
        best_entry = best_target_entry
        best_score = best_target_sim

    # Case 2: Pure 1:N Face Scan ("Scan My Face & Auto-Detect My Profile")
    else:
        if not best_user or best_score < MATCH_THRESHOLD:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=(
                    "BIOMETRIC IDENTITY NOT RECOGNIZED: Your face does not match any enrolled OEM, Auditor, or Registered Second-Life Buyer."
                ),
            )

    token = create_access_token(best_user)
    return FaceMatchLoginResponse(
        access_token=token,
        token_type="bearer",
        user=serialize_user(best_user, active_customer=best_entry),
        similarity_score=round(min(99.8, best_score * 100), 1),
        match_mode="BIOMETRIC_FACIAL_SCAN",
    )


@app.get("/api/me", response_model=UserOut)
def get_me(current_user: User = Depends(get_current_user)):
    return serialize_user(current_user)


@app.get("/api/batteries", response_model=List[BatteryOut])
def list_batteries(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    batteries = db.query(Battery).order_by(Battery.id.asc()).all()
    return [serialize_battery_for_role(b, current_user.role) for b in batteries]


@app.post("/api/batteries", response_model=BatteryOut, status_code=status.HTTP_201_CREATED)
def create_battery(
    payload: BatteryCreate,
    current_user: User = Depends(require_roles(["OEM_ADMIN"])),
    db: Session = Depends(get_db),
):
    passport_id = payload.passport_id
    if not passport_id or not passport_id.strip():
        suffix = secrets.token_hex(3)
        passport_id = f"EU-DBP-2027-{suffix}"

    existing = db.query(Battery).filter(Battery.passport_id == passport_id).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Battery Passport ID '{passport_id}' already exists in the EU registry.",
        )

    new_battery = Battery(
        passport_id=passport_id,
        model_name=payload.model_name,
        manufacturer=payload.manufacturer,
        manufacturing_date=payload.manufacturing_date,
        chemistry=payload.chemistry,
        nominal_capacity_kwh=payload.nominal_capacity_kwh,
        state_of_health_pct=payload.state_of_health_pct,
        charge_cycles=payload.charge_cycles,
        internal_resistance_mohm=payload.internal_resistance_mohm,
        carbon_footprint_kg_per_kwh=payload.carbon_footprint_kg_per_kwh,
        cobalt_origin=payload.cobalt_origin,
        recycled_cobalt_pct=payload.recycled_cobalt_pct,
        recycled_lithium_pct=payload.recycled_lithium_pct,
        recycled_nickel_pct=payload.recycled_nickel_pct,
        audit_notes=payload.audit_notes,
        compliance_status=payload.compliance_status,
        market_status=payload.market_status,
    )
    db.add(new_battery)
    db.commit()
    db.refresh(new_battery)
    return serialize_battery_for_role(new_battery, current_user.role)


@app.patch("/api/batteries/{battery_id}/audit", response_model=BatteryOut)
def audit_battery(
    battery_id: int,
    payload: AuditUpdateRequest = None,
    current_user: User = Depends(require_roles(["EU_AUDITOR"])),
    db: Session = Depends(get_db),
):
    battery = db.query(Battery).filter(Battery.id == battery_id).first()
    if not battery:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Battery passport not found.")

    if payload and payload.compliance_status in ("VERIFIED", "FLAGGED_NON_COMPLIANT", "PENDING_AUDIT"):
        battery.compliance_status = payload.compliance_status
    else:
        # Toggle between VERIFIED and FLAGGED_NON_COMPLIANT
        if battery.compliance_status == "VERIFIED":
            battery.compliance_status = "FLAGGED_NON_COMPLIANT"
        else:
            battery.compliance_status = "VERIFIED"

    if payload and payload.audit_notes:
        battery.audit_notes = payload.audit_notes
    else:
        if battery.compliance_status == "VERIFIED":
            battery.audit_notes = f"Verified compliant by {current_user.name} (TÜV Notified Body) under Art. 77."
        else:
            battery.audit_notes = f"Flagged non-compliant by {current_user.name} during Annex XIII supply-chain audit."

    db.commit()
    db.refresh(battery)
    return serialize_battery_for_role(battery, current_user.role)


@app.post("/api/batteries/{battery_id}/evaluate-second-life", response_model=SecondLifeEvaluationOut)
def evaluate_second_life(
    battery_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    battery = db.query(Battery).filter(Battery.id == battery_id).first()
    if not battery:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Battery passport not found.")

    soh = battery.state_of_health_pct
    usable_capacity_kwh = round(battery.nominal_capacity_kwh * (soh / 100.0), 2)
    tier_rate = 95.0 if soh > 80.0 else 65.0
    estimated_resale_value_eur = round(usable_capacity_kwh * tier_rate, 2)

    if soh >= 80.0:
        recommended_application = "Commercial C&I Peak Shaving / Fast Charger Buffer"
    elif soh >= 70.0:
        recommended_application = "Residential Solar Stationary Storage"
    else:
        recommended_application = "Direct Hydrometallurgical Recycling (Material Recovery)"

    return SecondLifeEvaluationOut(
        battery_id=battery.id,
        passport_id=battery.passport_id,
        model_name=battery.model_name,
        nominal_capacity_kwh=battery.nominal_capacity_kwh,
        state_of_health_pct=soh,
        usable_capacity_kwh=usable_capacity_kwh,
        tier_rate_eur_per_kwh=tier_rate,
        estimated_resale_value_eur=estimated_resale_value_eur,
        recommended_application=recommended_application,
    )


@app.patch("/api/batteries/{battery_id}/purchase", response_model=BatteryOut)
def purchase_battery_second_life(
    battery_id: int,
    current_user: User = Depends(require_roles(["SECOND_LIFE_BUYER"])),
    db: Session = Depends(get_db),
):
    battery = db.query(Battery).filter(Battery.id == battery_id).first()
    if not battery:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Battery passport not found.")

    if battery.market_status == "REPURPOSED_GRID_STORAGE":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Battery pack has already been repurposed and assigned a Second-Life Passport.",
        )

    battery.market_status = "REPURPOSED_GRID_STORAGE"
    suffix = secrets.token_hex(3)
    battery.second_life_passport_id = f"EU-DBP-SL-2027-{suffix}"

    db.commit()
    db.refresh(battery)
    return serialize_battery_for_role(battery, current_user.role)
